import {
  UserProfile,
  Workout,
  TrainingProgram,
  CompletedWorkoutLog,
  PersonalRecord,
  BodyMeasurementLog,
  MealLog,
  WaterLog,
  Challenge,
  FoodItem
} from '../types/fitness';
import {
  DEFAULT_USER_PROFILE,
  SAMPLE_WORKOUTS,
  SAMPLE_PROGRAMS,
  SAMPLE_FOOD_DATABASE,
  DEFAULT_PERSONAL_RECORDS,
  INITIAL_CHALLENGES,
  INITIAL_BODY_MEASUREMENTS,
  SAMPLE_WORKOUT_HISTORY
} from '../data/initialData';

const KEYS = {
  USER_PROFILE: 'mk_intensive_user_profile',
  WORKOUTS: 'mk_intensive_workouts',
  PROGRAMS: 'mk_intensive_programs',
  WORKOUT_LOGS: 'mk_intensive_workout_logs',
  PERSONAL_RECORDS: 'mk_intensive_personal_records',
  BODY_MEASUREMENTS: 'mk_intensive_body_measurements',
  MEAL_LOGS: 'mk_intensive_meal_logs',
  WATER_LOGS: 'mk_intensive_water_logs',
  CHALLENGES: 'mk_intensive_challenges',
  FOOD_ITEMS: 'mk_intensive_food_items',
};

// Helper for type-safe local storage
function getItem<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    console.warn(`Error reading localStorage key "${key}":`, e);
    return fallback;
  }
}

function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event('mk_storage_updated'));
  } catch (e) {
    console.error(`Error writing localStorage key "${key}":`, e);
  }
}

export const storage = {
  // USER PROFILE
  getProfile(): UserProfile {
    return getItem<UserProfile>(KEYS.USER_PROFILE, DEFAULT_USER_PROFILE);
  },
  saveProfile(profile: UserProfile): void {
    setItem(KEYS.USER_PROFILE, profile);
  },
  needsOnboarding(): boolean {
    const profile = this.getProfile();
    return !profile.isOnboarded;
  },

  // WORKOUTS
  getWorkouts(): Workout[] {
    return getItem<Workout[]>(KEYS.WORKOUTS, SAMPLE_WORKOUTS);
  },
  getWorkoutById(id: string): Workout | undefined {
    return this.getWorkouts().find(w => w.id === id);
  },

  // PROGRAMS
  getPrograms(): TrainingProgram[] {
    return getItem<TrainingProgram[]>(KEYS.PROGRAMS, SAMPLE_PROGRAMS);
  },
  getProgramById(id: string): TrainingProgram | undefined {
    return this.getPrograms().find(p => p.id === id);
  },
  getActiveProgram(): TrainingProgram {
    const profile = this.getProfile();
    const program = this.getProgramById(profile.currentProgramId || '');
    return program || this.getPrograms()[0];
  },
  saveActiveProgram(program: TrainingProgram): void {
    const profile = this.getProfile();
    profile.currentProgramId = program.id;
    this.saveProfile(profile);
  },

  // WORKOUT LOGS
  getWorkoutLogs(): CompletedWorkoutLog[] {
    return getItem<CompletedWorkoutLog[]>(KEYS.WORKOUT_LOGS, SAMPLE_WORKOUT_HISTORY);
  },
  addWorkoutLog(log: CompletedWorkoutLog): void {
    const logs = this.getWorkoutLogs();
    logs.unshift(log);
    setItem(KEYS.WORKOUT_LOGS, logs);

    // Update streak and last workout date
    const profile = this.getProfile();
    const todayStr = new Date().toISOString().split('T')[0];
    if (profile.lastWorkoutDate !== todayStr) {
      profile.streakDays = (profile.streakDays || 0) + 1;
      profile.lastWorkoutDate = todayStr;
      this.saveProfile(profile);
    }
  },

  // PERSONAL RECORDS
  getPRs(): PersonalRecord[] {
    return getItem<PersonalRecord[]>(KEYS.PERSONAL_RECORDS, DEFAULT_PERSONAL_RECORDS);
  },
  checkAndUpdatePR(exerciseName: string, weightKg: number, reps: number): { isNewPR: boolean; previousKg?: number } {
    const prs = this.getPRs();
    const existingIndex = prs.findIndex(p => p.exerciseName.toLowerCase() === exerciseName.toLowerCase());

    if (existingIndex >= 0) {
      const existing = prs[existingIndex];
      if (weightKg > existing.weightKg || (weightKg === existing.weightKg && reps > existing.reps)) {
        const previousKg = existing.weightKg;
        prs[existingIndex] = {
          exerciseName,
          weightKg,
          reps,
          dateISO: new Date().toISOString(),
          previousRecordKg: previousKg,
        };
        setItem(KEYS.PERSONAL_RECORDS, prs);
        return { isNewPR: true, previousKg };
      }
      return { isNewPR: false, previousKg: existing.weightKg };
    } else {
      prs.push({
        exerciseName,
        weightKg,
        reps,
        dateISO: new Date().toISOString(),
      });
      setItem(KEYS.PERSONAL_RECORDS, prs);
      return { isNewPR: true };
    }
  },

  // BODY MEASUREMENTS & TRANSFORMATION
  getBodyMeasurements(): BodyMeasurementLog[] {
    return getItem<BodyMeasurementLog[]>(KEYS.BODY_MEASUREMENTS, INITIAL_BODY_MEASUREMENTS);
  },
  addBodyMeasurement(log: BodyMeasurementLog): void {
    const logs = this.getBodyMeasurements();
    logs.unshift(log);
    setItem(KEYS.BODY_MEASUREMENTS, logs);

    // Also update weight in user profile
    if (log.weightKg) {
      const profile = this.getProfile();
      profile.weightKg = log.weightKg;
      this.saveProfile(profile);
    }
  },

  // NUTRITION & MEALS
  getMealLogs(dateISO?: string): MealLog[] {
    const logs = getItem<MealLog[]>(KEYS.MEAL_LOGS, []);
    const targetDate = dateISO || new Date().toISOString().split('T')[0];
    return logs.filter(m => m.dateISO === targetDate);
  },
  addMealLog(meal: Omit<MealLog, 'id' | 'dateISO'> & { dateISO?: string }): void {
    const logs = getItem<MealLog[]>(KEYS.MEAL_LOGS, []);
    const newMeal: MealLog = {
      ...meal,
      id: 'meal-' + Date.now(),
      dateISO: meal.dateISO || new Date().toISOString().split('T')[0],
    };
    logs.unshift(newMeal);
    setItem(KEYS.MEAL_LOGS, logs);
  },
  deleteMealLog(id: string): void {
    const logs = getItem<MealLog[]>(KEYS.MEAL_LOGS, []);
    const filtered = logs.filter(m => m.id !== id);
    setItem(KEYS.MEAL_LOGS, filtered);
  },

  // WATER LOGS
  getWaterLog(dateISO?: string): number {
    const logs = getItem<Record<string, number>>(KEYS.WATER_LOGS, {});
    const targetDate = dateISO || new Date().toISOString().split('T')[0];
    return logs[targetDate] || 0;
  },
  addWater(liters: number, dateISO?: string): void {
    const logs = getItem<Record<string, number>>(KEYS.WATER_LOGS, {});
    const targetDate = dateISO || new Date().toISOString().split('T')[0];
    const current = logs[targetDate] || 0;
    logs[targetDate] = parseFloat((current + liters).toFixed(1));
    setItem(KEYS.WATER_LOGS, logs);
  },

  // FOOD ITEMS DATABASE
  getFoodItems(): FoodItem[] {
    return getItem<FoodItem[]>(KEYS.FOOD_ITEMS, SAMPLE_FOOD_DATABASE);
  },
  addCustomFoodItem(food: Omit<FoodItem, 'id'>): void {
    const foods = this.getFoodItems();
    const newFood: FoodItem = {
      ...food,
      id: 'food-' + Date.now(),
    };
    foods.unshift(newFood);
    setItem(KEYS.FOOD_ITEMS, foods);
  },

  // CHALLENGES
  getChallenges(): Challenge[] {
    return getItem<Challenge[]>(KEYS.CHALLENGES, INITIAL_CHALLENGES);
  },
  updateChallengeProgress(id: string, delta: number): void {
    const challenges = this.getChallenges();
    const index = challenges.findIndex(c => c.id === id);
    if (index >= 0) {
      const c = challenges[index];
      c.currentValue = Math.min(c.targetValue, c.currentValue + delta);
      if (c.currentValue >= c.targetValue) {
        c.isCompleted = true;
      }
      setItem(KEYS.CHALLENGES, challenges);
    }
  },

  // RESET ALL DATA TO DEMO DEFAULT
  resetData(): void {
    localStorage.clear();
    window.dispatchEvent(new Event('mk_storage_updated'));
  },
  resetAllData(): void {
    this.resetData();
  }
};
