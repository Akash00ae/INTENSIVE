import React, { useState } from 'react';
import { Camera, Plus, Upload } from 'lucide-react';
import { BodyMeasurementLog } from '../types/fitness';
import { storage } from '../services/storage';

export const TransformationView: React.FC = () => {
  const [measurements, setMeasurements] = useState<BodyMeasurementLog[]>(
    storage.getBodyMeasurements()
  );

  // Form modal state for new measurement
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newWeight, setNewWeight] = useState(76.0);
  const [newWaist, setNewWaist] = useState(80);
  const [newChest, setNewChest] = useState(104);
  const [newArms, setNewArms] = useState(38);
  const [newThighs] = useState(60);
  const [newBodyFat, setNewBodyFat] = useState(14.5);
  const [newWeekLabel, setNewWeekLabel] = useState('Week 16');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveMeasurement = () => {
    const newLog: BodyMeasurementLog = {
      dateISO: new Date().toISOString(),
      weightKg: newWeight,
      waistCm: newWaist,
      chestCm: newChest,
      armsCm: newArms,
      thighsCm: newThighs,
      bodyFatPercentage: newBodyFat,
      weekLabel: newWeekLabel,
      photoUrl: photoPreview || undefined,
    };

    storage.addBodyMeasurement(newLog);
    setMeasurements(storage.getBodyMeasurements());
    setIsModalOpen(false);
    setPhotoPreview(null);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Title & Add Entry CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1F1F22] pb-6">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">Body Transformation</h1>
          <p className="text-[#666] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-medium">
            Visual progression timeline and circumferential body measurements.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center justify-center gap-2 bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs px-6 py-3.5 rounded-2xl uppercase tracking-widest transition-colors cursor-pointer shadow-xl shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>LOG MEASUREMENT</span>
        </button>
      </div>

      {/* MILESTONE TIMELINE SHOWCASE */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {measurements.map((item, index) => (
          <div
            key={index}
            className="bg-[#161618] border border-[#1F1F22] rounded-3xl overflow-hidden hover:border-[#333] transition-all shadow-xl group"
          >
            {/* Photo / Avatar Box */}
            <div className="relative aspect-[3/4] bg-[#0A0A0B] flex items-center justify-center overflow-hidden border-b border-[#1F1F22]">
              {item.photoUrl ? (
                <img src={item.photoUrl} alt={item.weekLabel} className="w-full h-full object-cover" />
              ) : (
                <div className="flex flex-col items-center justify-center text-[#666] p-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-[#161618] border border-[#222] flex items-center justify-center mb-3 text-[#D4FF44]">
                    <Camera className="w-8 h-8" />
                  </div>
                  <span className="text-xs font-black uppercase text-[#EAEAEA] tracking-wider">{item.weekLabel} SNAPSHOT</span>
                  <span className="text-[10px] text-[#666] mt-1 uppercase font-bold tracking-wider">No photo attached</span>
                </div>
              )}

              <div className="absolute top-3 left-3 bg-[#0A0A0B]/90 border border-[#222] px-3 py-1 rounded-xl font-black text-[#D4FF44] text-[10px] uppercase tracking-widest">
                {item.weekLabel || `Phase ${index + 1}`}
              </div>
            </div>

            {/* Metrics Breakdown */}
            <div className="p-5 space-y-3 bg-[#161618]">
              <div className="flex items-center justify-between pb-2 border-b border-[#222]">
                <span className="text-[10px] text-[#666] uppercase font-bold tracking-wider">Weight</span>
                <span className="text-sm font-black text-white uppercase">{item.weightKg} kg</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-[#0A0A0B] p-2.5 rounded-xl border border-[#222]">
                  <span className="text-[#666] block text-[9px] uppercase font-bold tracking-wider">Waist</span>
                  <span className="font-bold text-[#EAEAEA] mt-0.5 block">{item.waistCm || '--'} cm</span>
                </div>
                <div className="bg-[#0A0A0B] p-2.5 rounded-xl border border-[#222]">
                  <span className="text-[#666] block text-[9px] uppercase font-bold tracking-wider">Chest</span>
                  <span className="font-bold text-[#EAEAEA] mt-0.5 block">{item.chestCm || '--'} cm</span>
                </div>
                <div className="bg-[#0A0A0B] p-2.5 rounded-xl border border-[#222]">
                  <span className="text-[#666] block text-[9px] uppercase font-bold tracking-wider">Arms</span>
                  <span className="font-bold text-[#EAEAEA] mt-0.5 block">{item.armsCm || '--'} cm</span>
                </div>
                <div className="bg-[#0A0A0B] p-2.5 rounded-xl border border-[#222]">
                  <span className="text-[#666] block text-[9px] uppercase font-bold tracking-wider">Body Fat</span>
                  <span className="font-bold text-[#D4FF44] mt-0.5 block">{item.bodyFatPercentage || '--'}%</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* NEW MEASUREMENT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6">
            
            <div className="flex items-center justify-between border-b border-[#222] pb-4">
              <h3 className="text-lg font-black text-white uppercase tracking-wider">Log Transformation Entry</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-[#666] hover:text-white cursor-pointer text-sm font-bold">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Week Label</label>
                <input
                  type="text"
                  value={newWeekLabel}
                  onChange={(e) => setNewWeekLabel(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3.5 py-2.5 text-white font-bold text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Weight (kg)</label>
                <input
                  type="number"
                  step="0.1"
                  value={newWeight}
                  onChange={(e) => setNewWeight(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3.5 py-2.5 text-white font-bold text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Waist (cm)</label>
                <input
                  type="number"
                  value={newWaist}
                  onChange={(e) => setNewWaist(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3.5 py-2.5 text-white font-bold text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Chest (cm)</label>
                <input
                  type="number"
                  value={newChest}
                  onChange={(e) => setNewChest(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3.5 py-2.5 text-white font-bold text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Arms (cm)</label>
                <input
                  type="number"
                  value={newArms}
                  onChange={(e) => setNewArms(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3.5 py-2.5 text-white font-bold text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Body Fat Est. (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={newBodyFat}
                  onChange={(e) => setNewBodyFat(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3.5 py-2.5 text-white font-bold text-xs"
                />
              </div>
            </div>

            {/* Photo Upload Section */}
            <div>
              <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-2">Upload Progress Photo</label>
              <label className="flex items-center justify-center gap-2 p-4 border border-dashed border-[#222] hover:border-[#D4FF44] rounded-2xl cursor-pointer bg-[#0A0A0B] text-[#888] hover:text-white transition-all">
                <Upload className="w-4 h-4 text-[#D4FF44]" />
                <span className="text-xs font-black uppercase tracking-wider">{photoPreview ? 'Photo Uploaded ✓' : 'Choose Progress Image'}</span>
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
            </div>

            <button
              onClick={handleSaveMeasurement}
              className="w-full bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs py-4 rounded-2xl transition-colors uppercase tracking-widest shadow-xl cursor-pointer"
            >
              SAVE TRANSFORMATION LOG
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
