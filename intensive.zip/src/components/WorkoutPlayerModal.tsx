import React, { useState, useEffect } from 'react';
import { Play, Pause, FastForward, CheckCircle2, Trophy, ArrowRight, X, Flame, RotateCcw, Plus, Minus, ChevronRight, Dumbbell } from 'lucide-react';
import { Workout, ExerciseSet, CompletedWorkoutLog } from '../types/fitness';
import { storage } from '../services/storage';

interface WorkoutPlayerModalProps {
  workout: Workout | null;
  onClose: () => void;
  onFinishWorkout: () => void;
}

export const WorkoutPlayerModal: React.FC<WorkoutPlayerModalProps> = ({ workout, onClose, onFinishWorkout }) => {
  if (!workout) return null;

  // Workout execution state
  const [exerciseIndex, setExerciseIndex] = useState(0);
  const [setIndex, setSetIndex] = useState(0);
  const [workoutStartTime] = useState<number>(Date.now());
  const [completedSetsCount, setCompletedSetsCount] = useState(0);
  const [totalVolumeKg, setTotalVolumeKg] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // Live exercise & set state
  const currentExercise = workout.exercises[exerciseIndex];
  const currentSet = currentExercise?.sets[setIndex];

  const [weightKg, setWeightKg] = useState<number>(currentSet?.targetWeightKg || 20);
  const [reps, setReps] = useState<number>(currentSet?.targetReps || 10);

  // Rest Timer state
  const [isResting, setIsResting] = useState(false);
  const [restSecondsLeft, setRestSecondsLeft] = useState<number>(currentExercise?.restSeconds || 90);
  const [isTimerPaused, setIsTimerPaused] = useState(false);

  // PR & Progression Feedback state
  const [prBanner, setPrBanner] = useState<{ isNewPR: boolean; msg?: string; recommendation?: string } | null>(null);

  // Sync weight & reps whenever exercise or set changes
  useEffect(() => {
    if (currentSet) {
      setWeightKg(currentSet.targetWeightKg || 20);
      setReps(currentSet.targetReps || 10);
    }
  }, [exerciseIndex, setIndex]);

  // Rest Timer countdown interval
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isResting && !isTimerPaused && restSecondsLeft > 0) {
      interval = setInterval(() => {
        setRestSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (isResting && restSecondsLeft === 0) {
      setIsResting(false);
      advanceNextSet();
    }
    return () => clearInterval(interval);
  }, [isResting, isTimerPaused, restSecondsLeft]);

  // Format seconds into MM:SS
  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Complete current set
  const handleCompleteSet = () => {
    const addedVolume = weightKg * reps;
    setTotalVolumeKg((prev) => prev + addedVolume);
    setCompletedSetsCount((prev) => prev + 1);

    // Check PR
    const prResult = storage.checkAndUpdatePR(currentExercise.exerciseName, weightKg, reps);
    if (prResult.isNewPR) {
      const nextWeight = (weightKg + 2.5).toFixed(1);
      setPrBanner({
        isNewPR: true,
        msg: `NEW REP PR on ${currentExercise.exerciseName}!`,
        recommendation: `Next session: Try ${nextWeight} kg`,
      });
    }

    // Trigger Rest Period
    setRestSecondsLeft(currentExercise.restSeconds || 90);
    setIsResting(true);
  };

  // Skip set or skip rest
  const handleSkipSet = () => {
    advanceNextSet();
  };

  const handleSkipRest = () => {
    setIsResting(false);
    advanceNextSet();
  };

  const handleAddRestTime = () => {
    setRestSecondsLeft((prev) => prev + 30);
  };

  // Advance to next set or next exercise
  const advanceNextSet = () => {
    setPrBanner(null);
    if (setIndex + 1 < currentExercise.sets.length) {
      setSetIndex(setIndex + 1);
    } else if (exerciseIndex + 1 < workout.exercises.length) {
      setExerciseIndex(exerciseIndex + 1);
      setSetIndex(0);
    } else {
      // All exercises completed!
      finishWorkoutSession();
    }
  };

  const finishWorkoutSession = () => {
    const durationSeconds = Math.max(60, Math.floor((Date.now() - workoutStartTime) / 1000));
    const newLog: CompletedWorkoutLog = {
      id: 'log-' + Date.now(),
      workoutId: workout.id,
      workoutTitle: workout.title,
      dateISO: new Date().toISOString(),
      dateFormatted: 'Just now',
      durationSeconds,
      totalVolumeKg,
      totalSetsCompleted: completedSetsCount + 1,
      totalExercisesCount: workout.exercises.length,
      exerciseLogs: workout.exercises.map((ex) => ({
        exerciseName: ex.exerciseName,
        sets: ex.sets.map((s) => ({ weightKg: s.targetWeightKg, reps: s.targetReps })),
      })),
    };

    storage.addWorkoutLog(newLog);
    setIsFinished(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[580px]">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800/80">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-amber-400">
              {workout.title}
            </div>
            {!isFinished && (
              <div className="text-xs text-zinc-400 mt-0.5">
                Exercise {exerciseIndex + 1} of {workout.exercises.length}
              </div>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-zinc-900 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* WORKOUT COMPLETE CELEBRATION VIEW */}
        {isFinished ? (
          <div className="my-auto text-center space-y-6 py-6">
            <div className="w-20 h-20 bg-[#D4FF44]/20 border-2 border-[#D4FF44] rounded-full flex items-center justify-center mx-auto text-[#D4FF44] animate-bounce">
              <Flame className="w-10 h-10 fill-[#D4FF44] text-[#D4FF44]" />
            </div>

            <div>
              <h2 className="text-3xl font-black text-white tracking-tight uppercase">WORKOUT COMPLETE 🔥</h2>
              <p className="text-xs text-[#888] mt-1 font-medium uppercase tracking-widest">Progressive overload logged to protocol.</p>
            </div>

            <div className="grid grid-cols-3 gap-3 bg-[#161618] p-4 rounded-2xl border border-[#1F1F22]">
              <div>
                <span className="text-[9px] font-bold text-[#666] uppercase tracking-wider block">Duration</span>
                <span className="text-lg font-black text-white">
                  {Math.round((Date.now() - workoutStartTime) / 60000)}m
                </span>
              </div>
              <div>
                <span className="text-[9px] font-bold text-[#666] uppercase tracking-wider block">Total Volume</span>
                <span className="text-lg font-black text-[#D4FF44]">
                  {totalVolumeKg.toLocaleString()} kg
                </span>
              </div>
              <div>
                <span className="text-[9px] font-bold text-[#666] uppercase tracking-wider block">Sets Done</span>
                <span className="text-lg font-black text-white">{completedSetsCount}</span>
              </div>
            </div>

            <button
              onClick={onFinishWorkout}
              className="w-full bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-sm py-4 rounded-2xl shadow-xl uppercase tracking-widest transition-colors cursor-pointer"
            >
              VIEW RESULTS
            </button>
          </div>
        ) : isResting ? (
          
          /* REST TIMER VIEW */
          <div className="my-auto text-center space-y-6 py-6">
            <span className="px-3 py-1 bg-[#D4FF44]/10 text-[#D4FF44] font-black text-[10px] uppercase tracking-widest rounded-md border border-[#D4FF44]/20">
              REST & RECOVER
            </span>

            <div className="text-6xl sm:text-7xl font-black font-mono text-white tracking-wider my-4">
              {formatTime(restSecondsLeft)}
            </div>

            {/* Rest Timer Actions */}
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setIsTimerPaused(!isTimerPaused)}
                className="px-4 py-2.5 bg-[#161618] border border-[#1F1F22] hover:bg-[#222] text-[#EAEAEA] font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all uppercase tracking-wider cursor-pointer"
              >
                {isTimerPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4" />}
                <span>{isTimerPaused ? 'Resume' : 'Pause'}</span>
              </button>

              <button
                onClick={handleAddRestTime}
                className="px-4 py-2.5 bg-[#161618] border border-[#1F1F22] hover:bg-[#222] text-[#D4FF44] font-bold text-xs rounded-xl flex items-center gap-1 transition-all uppercase tracking-wider cursor-pointer"
              >
                +30 Seconds
              </button>

              <button
                onClick={handleSkipRest}
                className="px-4 py-2.5 bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs rounded-xl flex items-center gap-1.5 transition-all uppercase tracking-wider cursor-pointer"
              >
                <span>Skip Rest</span>
                <FastForward className="w-4 h-4 fill-black" />
              </button>
            </div>

            <div className="text-xs text-[#666] pt-4 border-t border-[#1F1F22] font-medium uppercase tracking-wider">
              Next Up: <span className="text-white font-bold">{currentExercise?.exerciseName}</span> (Set {setIndex + 1})
            </div>
          </div>
        ) : (
          
          /* ACTIVE EXERCISE & SET PLAYER */
          <div className="my-auto space-y-6 py-4">
            
            {/* PR Banner if triggered */}
            {prBanner && (
              <div className="bg-[#D4FF44]/10 border border-[#D4FF44]/30 p-3.5 rounded-2xl flex items-center gap-3">
                <Trophy className="w-6 h-6 text-[#D4FF44] shrink-0" />
                <div>
                  <div className="text-xs font-black text-[#D4FF44] uppercase tracking-wider">{prBanner.msg}</div>
                  <div className="text-xs text-[#EAEAEA] font-semibold">{prBanner.recommendation}</div>
                </div>
              </div>
            )}

            {/* Exercise Title & Previous Benchmark */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em]">
                  Target: {currentExercise?.targetMuscle}
                </span>
                <span className="text-[10px] font-black text-[#D4FF44] bg-[#D4FF44]/10 px-2.5 py-1 rounded-md border border-[#D4FF44]/20 uppercase tracking-widest">
                  Set {setIndex + 1} of {currentExercise?.sets.length}
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">
                {currentExercise?.exerciseName}
              </h2>

              <div className="text-xs text-[#666] mt-1 flex items-center gap-2">
                <span className="uppercase font-bold tracking-wider text-[10px]">Last benchmark:</span>
                <span className="text-[#EAEAEA] font-bold bg-[#161618] px-2 py-0.5 rounded border border-[#222]">
                  {(currentSet?.targetWeightKg || 20) - 2} kg × {(currentSet?.targetReps || 10) - 1} reps
                </span>
              </div>
            </div>

            {/* Weight & Reps Counter Controls */}
            <div className="grid grid-cols-2 gap-4">
              
              {/* Weight Selector */}
              <div className="bg-[#161618] border border-[#1F1F22] p-4 rounded-2xl text-center">
                <span className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-2">Weight (kg)</span>
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => setWeightKg(Math.max(0, weightKg - 2.5))}
                    className="w-10 h-10 rounded-xl bg-[#0A0A0B] border border-[#222] hover:bg-[#222] text-white font-bold flex items-center justify-center transition-all cursor-pointer active:scale-90"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-3xl font-black text-white font-mono">{weightKg}</span>
                  <button
                    onClick={() => setWeightKg(weightKg + 2.5)}
                    className="w-10 h-10 rounded-xl bg-[#0A0A0B] border border-[#222] hover:bg-[#222] text-white font-bold flex items-center justify-center transition-all cursor-pointer active:scale-90"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Reps Selector */}
              <div className="bg-[#161618] border border-[#1F1F22] p-4 rounded-2xl text-center">
                <span className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-2">Reps</span>
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => setReps(Math.max(1, reps - 1))}
                    className="w-10 h-10 rounded-xl bg-[#0A0A0B] border border-[#222] hover:bg-[#222] text-white font-bold flex items-center justify-center transition-all cursor-pointer active:scale-90"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-3xl font-black text-white font-mono">{reps}</span>
                  <button
                    onClick={() => setReps(reps + 1)}
                    className="w-10 h-10 rounded-xl bg-[#0A0A0B] border border-[#222] hover:bg-[#222] text-white font-bold flex items-center justify-center transition-all cursor-pointer active:scale-90"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>

            {/* Complete / Skip Buttons */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={handleSkipSet}
                className="py-3.5 bg-[#161618] hover:bg-[#222] border border-[#1F1F22] text-[#888] font-bold text-xs rounded-2xl transition-all uppercase tracking-widest cursor-pointer"
              >
                Skip Set
              </button>

              <button
                onClick={handleCompleteSet}
                className="py-3.5 bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs rounded-2xl transition-all flex items-center justify-center gap-2 uppercase tracking-widest cursor-pointer shadow-lg active:scale-95"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>COMPLETE SET</span>
              </button>
            </div>

          </div>
        )}

        {/* Footer Progress Dots */}
        {!isFinished && (
          <div className="pt-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-500">
            <span>Completed sets: {completedSetsCount}</span>
            <span>Total volume: {totalVolumeKg} kg</span>
          </div>
        )}

      </div>
    </div>
  );
};
