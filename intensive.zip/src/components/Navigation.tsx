import React from 'react';
import { Home, Dumbbell, TrendingUp, Utensils, User, Trophy, Sparkles } from 'lucide-react';

export type NavTab = 'home' | 'workouts' | 'programs' | 'progress' | 'transformation' | 'nutrition' | 'coach' | 'challenges' | 'profile';

interface NavigationProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onSelectTab }) => {
  const mainNavItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'workouts', label: 'Workouts', icon: Dumbbell },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
    { id: 'nutrition', label: 'Nutrition', icon: Utensils },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  const secondaryNavItems = [
    { id: 'programs', label: 'Programs' },
    { id: 'transformation', label: 'Transformation' },
    { id: 'coach', label: 'AI Coach', icon: Sparkles },
    { id: 'challenges', label: 'Challenges', icon: Trophy },
  ];

  return (
    <>
      {/* Desktop Sidebar Navigation */}
      <aside className="hidden md:flex flex-col w-64 bg-[#0A0A0B] border-r border-[#1F1F22] p-6 shrink-0 min-h-[calc(100vh-61px)]">
        <div className="space-y-8 flex-1">
          <div>
            <p className="px-3 text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-4">Main Menu</p>
            <nav className="space-y-2">
              {mainNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id as NavTab)}
                    className={`w-full flex items-center gap-4 px-3 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all relative ${
                      isActive
                        ? 'text-[#D4FF44]'
                        : 'text-[#888] hover:text-white'
                    }`}
                  >
                    {isActive && (
                      <div className="w-1 h-6 bg-[#D4FF44] rounded-full absolute -left-6" />
                    )}
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#D4FF44]' : 'text-[#666]'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div>
            <p className="px-3 text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-4">Programs & Tools</p>
            <nav className="space-y-2">
              {secondaryNavItems.map((item) => {
                const isActive = activeTab === item.id;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id as NavTab)}
                    className={`w-full flex items-center gap-4 px-3 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all relative ${
                      isActive
                        ? 'text-[#D4FF44]'
                        : 'text-[#888] hover:text-white'
                    }`}
                  >
                    {isActive && (
                      <div className="w-1 h-6 bg-[#D4FF44] rounded-full absolute -left-6" />
                    )}
                    {Icon ? (
                      <Icon className={`w-4 h-4 ${isActive ? 'text-[#D4FF44]' : 'text-[#666]'}`} />
                    ) : (
                      <div className={`w-1.5 h-1.5 rounded-full ml-1 ${isActive ? 'bg-[#D4FF44]' : 'bg-[#444]'}`} />
                    )}
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Head Coach Signature in Navigation */}
          <div className="pt-8 border-t border-[#1F1F22]">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-[#161618] border border-[#D4FF44]/40 flex items-center justify-center text-xs font-black text-[#D4FF44]">SA</div>
              <div>
                <div className="text-xs font-black text-white uppercase">SR Abhishek</div>
                <div className="text-[10px] text-[#D4FF44] uppercase tracking-wider font-bold">INTENSIVE Coach</div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0A0A0B]/95 backdrop-blur-md border-t border-[#1F1F22] px-2 py-1.5 pb-safe">
        <div className="grid grid-cols-5 gap-1 max-w-md mx-auto">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id as NavTab)}
                className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all ${
                  isActive ? 'text-[#D4FF44] font-bold' : 'text-[#666] hover:text-[#888]'
                }`}
              >
                <Icon className={`w-5 h-5 mb-1 transition-transform ${isActive ? 'scale-110 text-[#D4FF44]' : ''}`} />
                <span className="text-[10px] tracking-tight leading-none uppercase font-bold">{item.label}</span>
                {isActive && (
                  <div className="w-1 h-1 rounded-full bg-[#D4FF44] mt-1" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
