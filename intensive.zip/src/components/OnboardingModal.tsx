import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  Check,
  Dumbbell,
  Sparkles,
  Flame,
  Activity,
  Zap,
  Target,
  Clock,
  MapPin,
  Calendar,
  ShieldAlert,
  ChevronRight,
  Scale
} from 'lucide-react';
import {
  UserProfile,
  FitnessGoal,
  ExperienceLevel,
  Equipment,
  TrainingProgram
} from '../types/fitness';
import { storage } from '../services/storage';

interface OnboardingModalProps {
  isOpen?: boolean;
  onComplete: (profile: UserProfile) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onComplete }) => {
  const [screen, setScreen] = useState<number>(1); // 1 to 12

  // Unit Toggles
  const [heightUnit, setHeightUnit] = useState<'cm' | 'ft/in'>('cm');
  const [heightFt, setHeightFt] = useState<number>(5);
  const [heightIn, setHeightIn] = useState<number>(7);

  const [weightUnit, setWeightUnit] = useState<'kg' | 'lb'>('kg');

  // Form State
  const [name, setName] = useState('Akash');
  const [age, setAge] = useState<number>(21);
  const [gender, setGender] = useState<'Male' | 'Female' | 'Prefer not to say'>('Male');

  const [heightCm, setHeightCm] = useState<number>(170);
  const [weightKg, setWeightKg] = useState<number>(72);
  const [targetWeightKg, setTargetWeightKg] = useState<number>(78);

  const [optionalMeasurements, setOptionalMeasurements] = useState({
    waistCm: 81,
    chestCm: 102,
    armsCm: 37,
    thighsCm: 58
  });

  const [trainingDurationExperience, setTrainingDurationExperience] = useState<string>('1–2 years');
  const [experience, setExperience] = useState<ExperienceLevel>('Intermediate');

  const [goal, setGoal] = useState<FitnessGoal>('Build Muscle');
  const [secondaryGoals, setSecondaryGoals] = useState<string[]>(['Build Strength']);

  const [physiquePriorities, setPhysiquePriorities] = useState<string[]>(['Chest', 'Arms', 'Shoulders']);

  const [trainingDaysPerWeek, setTrainingDaysPerWeek] = useState<number>(5);
  const [preferredDurationMin, setPreferredDurationMin] = useState<number>(60);

  const [location, setLocation] = useState<'Full Gym' | 'Home Gym' | 'Home' | 'Outdoor' | 'Mixed'>('Full Gym');
  const [availableEquipmentList, setAvailableEquipmentList] = useState<string[]>([
    'Barbell', 'Dumbbells', 'Bench', 'Squat Rack', 'Cable Machine', 'Machines'
  ]);

  const [preferredTrainingTypes, setPreferredTrainingTypes] = useState<string[]>([
    'Bodybuilding', 'Strength Training'
  ]);
  const [perceivedIntensity, setPerceivedIntensity] = useState<'Moderate' | 'Challenging' | 'Very Intense'>('Very Intense');

  const [outsideActivity, setOutsideActivity] = useState<'Mostly sedentary' | 'Lightly active' | 'Moderately active' | 'Very active'>('Moderately active');
  const [dailySteps, setDailySteps] = useState<string>('8,000–10,000');
  const [sleepDuration, setSleepDuration] = useState<string>('7–8 hours');
  const [workLifeActivity, setWorkLifeActivity] = useState<'Desk-based' | 'Mixed' | 'Physically active'>('Mixed');

  const [preferredSplit, setPreferredSplit] = useState<'Full Body' | 'Upper / Lower' | 'Push / Pull / Legs' | 'Body-Part Split' | 'Let INTENSIVE decide'>('Push / Pull / Legs');

  // Convert height if ft/in
  const effectiveHeightCm = heightUnit === 'ft/in'
    ? Math.round((heightFt * 12 + heightIn) * 2.54)
    : heightCm;

  // Convert weight to kg for calculations
  const effectiveWeightKg = weightUnit === 'lb' ? Math.round(weightKg * 0.453592) : weightKg;
  const effectiveTargetWeightKg = weightUnit === 'lb' ? Math.round(targetWeightKg * 0.453592) : targetWeightKg;

  // Calculate Calorie & Protein Targets (Estimates)
  const calculateEstimates = () => {
    const bmr = gender === 'Female'
      ? 10 * effectiveWeightKg + 6.25 * effectiveHeightCm - 5 * age - 161
      : 10 * effectiveWeightKg + 6.25 * effectiveHeightCm - 5 * age + 5;

    let activityMultiplier = 1.375;
    if (outsideActivity === 'Mostly sedentary') activityMultiplier = 1.2;
    if (outsideActivity === 'Moderately active') activityMultiplier = 1.55;
    if (outsideActivity === 'Very active') activityMultiplier = 1.725;

    let maintenanceCalories = Math.round(bmr * activityMultiplier);
    let calorieTarget = maintenanceCalories;

    if (goal === 'Build Muscle') calorieTarget += 350;
    else if (goal === 'Lose Fat') calorieTarget -= 450;
    else if (goal === 'Increase Strength') calorieTarget += 200;
    else if (goal === 'Improve Fitness') calorieTarget = maintenanceCalories;

    const proteinTarget = Math.round(effectiveWeightKg * 2.2);

    return {
      calories: Math.max(1600, calorieTarget),
      protein: Math.max(100, proteinTarget)
    };
  };

  const estimates = calculateEstimates();

  // Helper for secondary goal toggle
  const toggleSecondaryGoal = (g: string) => {
    if (secondaryGoals.includes(g)) {
      setSecondaryGoals(secondaryGoals.filter(item => item !== g));
    } else {
      setSecondaryGoals([...secondaryGoals, g]);
    }
  };

  // Helper for physique priorities toggle
  const togglePhysiquePriority = (p: string) => {
    if (p === 'No specific preference') {
      setPhysiquePriorities(['No specific preference']);
      return;
    }
    const filtered = physiquePriorities.filter(item => item !== 'No specific preference');
    if (filtered.includes(p)) {
      setPhysiquePriorities(filtered.filter(item => item !== p));
    } else {
      setPhysiquePriorities([...filtered, p]);
    }
  };

  // Helper for equipment toggle
  const toggleEquipment = (eq: string) => {
    if (availableEquipmentList.includes(eq)) {
      setAvailableEquipmentList(availableEquipmentList.filter(item => item !== eq));
    } else {
      setAvailableEquipmentList([...availableEquipmentList, eq]);
    }
  };

  // Helper for training types toggle
  const toggleTrainingType = (tt: string) => {
    if (preferredTrainingTypes.includes(tt)) {
      setPreferredTrainingTypes(preferredTrainingTypes.filter(item => item !== tt));
    } else {
      setPreferredTrainingTypes([...preferredTrainingTypes, tt]);
    }
  };

  // Determine split if "Let INTENSIVE decide"
  const getComputedSplit = () => {
    if (preferredSplit !== 'Let INTENSIVE decide') return preferredSplit;
    if (trainingDaysPerWeek <= 3) return 'Full Body';
    if (trainingDaysPerWeek === 4) return 'Upper / Lower';
    if (trainingDaysPerWeek >= 5) return 'Push / Pull / Legs';
    return 'Push / Pull / Legs';
  };

  const finalSplit = getComputedSplit();

  // Complete Onboarding & Save
  const handleCompleteProgram = () => {
    const equipmentMapped: Equipment = location === 'Full Gym' ? 'Full Gym' : (location === 'Home Gym' ? 'Home Gym' : 'Dumbbells');

    const updatedProfile: UserProfile = {
      name: name || 'Akash',
      age: Number(age) || 21,
      gender: gender,
      heightCm: effectiveHeightCm,
      heightUnit: heightUnit,
      weightKg: effectiveWeightKg,
      weightUnit: weightUnit,
      targetWeightKg: effectiveTargetWeightKg,
      optionalMeasurements,
      trainingDurationExperience,
      experience,
      goal,
      secondaryGoals,
      physiquePriorities,
      trainingDaysPerWeek,
      preferredDurationMin,
      location,
      availableEquipmentList,
      equipment: equipmentMapped,
      preferredTrainingTypes,
      perceivedIntensity,
      outsideActivity,
      dailySteps,
      sleepDuration,
      workLifeActivity,
      preferredSplit,
      estimatedDailyCalories: estimates.calories,
      estimatedDailyProteinG: estimates.protein,
      currentProgramId: 'prog-6wk-muscle',
      isOnboarded: true,
      streakDays: 1,
      lastWorkoutDate: new Date().toISOString().split('T')[0],
    };

    storage.saveProfile(updatedProfile);
    onComplete(updatedProfile);
  };

  // Skip / Sample Account Bypass
  const handleExistingAccount = () => {
    const profile = storage.getProfile();
    profile.isOnboarded = true;
    storage.saveProfile(profile);
    onComplete(profile);
  };

  // Dynamic schedule generator for Screen 12 preview
  const getDynamicWeeklySchedule = () => {
    if (trainingDaysPerWeek === 3) {
      return [
        { day: 'MONDAY', title: 'FULL BODY HYPERTROPHY A', rest: false },
        { day: 'TUESDAY', title: 'REST & RECOVERY', rest: true },
        { day: 'WEDNESDAY', title: 'FULL BODY STRENGTH B', rest: false },
        { day: 'THURSDAY', title: 'REST & RECOVERY', rest: true },
        { day: 'FRIDAY', title: 'FULL BODY POWER C', rest: false },
        { day: 'SATURDAY', title: 'ACTIVE MOBILITY', rest: true },
        { day: 'SUNDAY', title: 'REST DAY', rest: true },
      ];
    } else if (trainingDaysPerWeek === 4) {
      return [
        { day: 'MONDAY', title: 'UPPER BODY POWER', rest: false },
        { day: 'TUESDAY', title: 'LOWER BODY DRIVE', rest: false },
        { day: 'WEDNESDAY', title: 'REST & RECOVERY', rest: true },
        { day: 'THURSDAY', title: 'UPPER BODY HYPERTROPHY', rest: false },
        { day: 'FRIDAY', title: 'LOWER BODY & CORE', rest: false },
        { day: 'SATURDAY', title: 'ACTIVE RECOVERY', rest: true },
        { day: 'SUNDAY', title: 'REST DAY', rest: true },
      ];
    } else if (trainingDaysPerWeek === 6) {
      return [
        { day: 'MONDAY', title: 'PUSH: CHEST, SHOULDERS, TRICEPS', rest: false },
        { day: 'TUESDAY', title: 'PULL: BACK, BICEPS, REAR DELTS', rest: false },
        { day: 'WEDNESDAY', title: 'LEGS: QUADS, GLUTES, CALVES', rest: false },
        { day: 'THURSDAY', title: 'PUSH: UPPER CHEST & DELT FOCUS', rest: false },
        { day: 'FRIDAY', title: 'PULL: LAT WIDTH & BICEPS', rest: false },
        { day: 'SATURDAY', title: 'LEGS: HAMSTRINGS & ABS', rest: false },
        { day: 'SUNDAY', title: 'REST DAY', rest: true },
      ];
    } else {
      // 5 days
      return [
        { day: 'MONDAY', title: 'CHEST + TRICEPS (PUSH)', rest: false },
        { day: 'TUESDAY', title: 'BACK + BICEPS (PULL)', rest: false },
        { day: 'WEDNESDAY', title: 'LEGS & ABS (LOWER)', rest: false },
        { day: 'THURSDAY', title: 'REST & RECOVERY', rest: true },
        { day: 'FRIDAY', title: 'SHOULDERS + ARMS (UPPER PUMP)', rest: false },
        { day: 'SATURDAY', title: 'CONDITIONING / ATHLETIC CORE', rest: false },
        { day: 'SUNDAY', title: 'REST DAY', rest: true },
      ];
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0A0A0B] text-white flex flex-col justify-between overflow-y-auto selection:bg-[#D4FF44] selection:text-black font-sans">
      {/* Top Header Navigation & Progress Bar */}
      {screen > 1 && (
        <div className="sticky top-0 z-30 bg-[#0A0A0B]/90 backdrop-blur-md border-b border-zinc-800/80 px-4 py-3 sm:px-8 flex items-center justify-between">
          <button
            onClick={() => setScreen(screen - 1)}
            className="flex items-center space-x-2 text-zinc-400 hover:text-white transition-colors text-sm font-semibold py-1.5 px-3 rounded-lg hover:bg-zinc-800/60"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>BACK</span>
          </button>

          <div className="flex flex-col items-center">
            <span className="text-xs font-mono tracking-widest text-[#D4FF44] uppercase font-bold">
              STEP {screen - 1} OF 11
            </span>
            <div className="w-32 sm:w-48 bg-zinc-800 h-1.5 rounded-full mt-1 overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#D4FF44] to-emerald-400 h-full transition-all duration-300"
                style={{ width: `${((screen - 1) / 11) * 100}%` }}
              ></div>
            </div>
          </div>

          <button
            onClick={handleExistingAccount}
            className="text-xs font-semibold text-zinc-500 hover:text-zinc-300 transition-colors uppercase tracking-wider hidden sm:block"
          >
            SKIP ASSESSMENT
          </button>
        </div>
      )}

      {/* Main Screen Content */}
      <div className="flex-1 flex flex-col justify-center max-w-3xl w-full mx-auto px-4 py-8 sm:px-8 sm:py-12">
        {/* SCREEN 1: WELCOME */}
        {screen === 1 && (
          <div className="flex flex-col items-center justify-center text-center space-y-8 py-12 animate-fade-in">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-zinc-900 border border-[#D4FF44]/30 text-[#D4FF44] text-xs font-mono font-bold tracking-widest uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>THE BODYBUILDING PROTOCOL</span>
            </div>

            <div className="space-y-4 max-w-2xl">
              <h1 className="text-5xl sm:text-7xl font-black tracking-tight text-white uppercase italic font-display">
                INTENSIVE
              </h1>
              <p className="text-2xl sm:text-4xl font-extrabold text-zinc-100 tracking-tight">
                YOUR TRANSFORMATION STARTS HERE.
              </p>
              <p className="text-base sm:text-lg text-zinc-400 font-medium max-w-lg mx-auto">
                Personalized training. Structured progression. Real results.
              </p>
            </div>

            <div className="w-full max-w-sm space-y-3 pt-6">
              <button
                onClick={() => setScreen(2)}
                className="w-full bg-[#D4FF44] hover:bg-[#c3f033] text-black font-extrabold text-lg uppercase py-4 px-6 rounded-2xl transition-all shadow-lg shadow-[#D4FF44]/10 hover:shadow-[#D4FF44]/20 flex items-center justify-center space-x-3 group"
              >
                <span>START ASSESSMENT</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={handleExistingAccount}
                className="w-full bg-zinc-900/90 hover:bg-zinc-800 text-zinc-300 font-bold text-sm uppercase py-3.5 px-6 rounded-2xl border border-zinc-800 hover:border-zinc-700 transition-all"
              >
                I ALREADY HAVE AN ACCOUNT
              </button>
            </div>
          </div>
        )}

        {/* SCREEN 2: BASIC INFORMATION */}
        {screen === 2 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 01 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">BASIC INFORMATION</h2>
              <p className="text-zinc-400 text-sm mt-1">Let's set up your athlete profile.</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  What is your name?
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-[#D4FF44] rounded-2xl px-5 py-4 text-white text-lg font-semibold outline-none transition-all placeholder:text-zinc-600"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  What is your age?
                </label>
                <input
                  type="number"
                  value={age || ''}
                  onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                  placeholder="e.g. 21"
                  className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-[#D4FF44] rounded-2xl px-5 py-4 text-white text-lg font-semibold outline-none transition-all placeholder:text-zinc-600"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  What is your gender?
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['Male', 'Female', 'Prefer not to say'] as const).map((g) => (
                    <button
                      key={g}
                      onClick={() => setGender(g)}
                      className={`py-3.5 px-4 rounded-xl font-bold text-sm border transition-all ${
                        gender === g
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 3: BODY INFORMATION */}
        {screen === 3 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 02 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">BODY INFORMATION</h2>
              <p className="text-zinc-400 text-sm mt-1">Accurate metrics allow precise calorie and progression calculations.</p>
            </div>

            <div className="space-y-6">
              {/* Height */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">Height</label>
                  <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800">
                    <button
                      onClick={() => setHeightUnit('cm')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                        heightUnit === 'cm' ? 'bg-[#D4FF44] text-black' : 'text-zinc-400'
                      }`}
                    >
                      CM
                    </button>
                    <button
                      onClick={() => setHeightUnit('ft/in')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                        heightUnit === 'ft/in' ? 'bg-[#D4FF44] text-black' : 'text-zinc-400'
                      }`}
                    >
                      FT/IN
                    </button>
                  </div>
                </div>

                {heightUnit === 'cm' ? (
                  <input
                    type="number"
                    value={heightCm || ''}
                    onChange={(e) => setHeightCm(parseInt(e.target.value) || 0)}
                    placeholder="e.g. 170"
                    className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-[#D4FF44] rounded-2xl px-5 py-4 text-white text-lg font-semibold outline-none transition-all"
                  />
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-xs text-zinc-500 font-bold uppercase">Feet</span>
                      <input
                        type="number"
                        value={heightFt || ''}
                        onChange={(e) => setHeightFt(parseInt(e.target.value) || 0)}
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#D4FF44] rounded-xl px-4 py-3 text-white font-bold"
                      />
                    </div>
                    <div>
                      <span className="text-xs text-zinc-500 font-bold uppercase">Inches</span>
                      <input
                        type="number"
                        value={heightIn || ''}
                        onChange={(e) => setHeightIn(parseInt(e.target.value) || 0)}
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#D4FF44] rounded-xl px-4 py-3 text-white font-bold"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Weights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">Current Weight</label>
                    <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800">
                      <button
                        onClick={() => setWeightUnit('kg')}
                        className={`px-2.5 py-0.5 rounded-lg text-xs font-bold ${
                          weightUnit === 'kg' ? 'bg-[#D4FF44] text-black' : 'text-zinc-400'
                        }`}
                      >
                        KG
                      </button>
                      <button
                        onClick={() => setWeightUnit('lb')}
                        className={`px-2.5 py-0.5 rounded-lg text-xs font-bold ${
                          weightUnit === 'lb' ? 'bg-[#D4FF44] text-black' : 'text-zinc-400'
                        }`}
                      >
                        LB
                      </button>
                    </div>
                  </div>
                  <input
                    type="number"
                    value={weightKg || ''}
                    onChange={(e) => setWeightKg(parseFloat(e.target.value) || 0)}
                    placeholder={`e.g. ${weightUnit === 'kg' ? '72' : '158'}`}
                    className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-[#D4FF44] rounded-2xl px-5 py-4 text-white text-lg font-semibold outline-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">Target Weight ({weightUnit.toUpperCase()})</label>
                  <input
                    type="number"
                    value={targetWeightKg || ''}
                    onChange={(e) => setTargetWeightKg(parseFloat(e.target.value) || 0)}
                    placeholder={`e.g. ${weightUnit === 'kg' ? '78' : '172'}`}
                    className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-[#D4FF44] rounded-2xl px-5 py-4 text-white text-lg font-semibold outline-none"
                  />
                </div>
              </div>

              {/* Optional Body Measurements */}
              <div className="pt-4 border-t border-zinc-800/80 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-zinc-300 uppercase tracking-wide">Optional Body Measurements (CM)</h3>
                  <span className="text-xs text-zinc-500 font-semibold uppercase">Optional</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="text-xs text-zinc-400 font-bold">Waist</label>
                    <input
                      type="number"
                      value={optionalMeasurements.waistCm || ''}
                      onChange={(e) => setOptionalMeasurements({ ...optionalMeasurements, waistCm: parseFloat(e.target.value) || 0 })}
                      placeholder="81 cm"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#D4FF44] rounded-xl px-3 py-2.5 text-white text-sm font-bold mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-400 font-bold">Chest</label>
                    <input
                      type="number"
                      value={optionalMeasurements.chestCm || ''}
                      onChange={(e) => setOptionalMeasurements({ ...optionalMeasurements, chestCm: parseFloat(e.target.value) || 0 })}
                      placeholder="102 cm"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#D4FF44] rounded-xl px-3 py-2.5 text-white text-sm font-bold mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-400 font-bold">Arms</label>
                    <input
                      type="number"
                      value={optionalMeasurements.armsCm || ''}
                      onChange={(e) => setOptionalMeasurements({ ...optionalMeasurements, armsCm: parseFloat(e.target.value) || 0 })}
                      placeholder="37 cm"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#D4FF44] rounded-xl px-3 py-2.5 text-white text-sm font-bold mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-zinc-400 font-bold">Thighs</label>
                    <input
                      type="number"
                      value={optionalMeasurements.thighsCm || ''}
                      onChange={(e) => setOptionalMeasurements({ ...optionalMeasurements, thighsCm: parseFloat(e.target.value) || 0 })}
                      placeholder="58 cm"
                      className="w-full bg-zinc-900 border border-zinc-800 focus:border-[#D4FF44] rounded-xl px-3 py-2.5 text-white text-sm font-bold mt-1"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 4: FITNESS EXPERIENCE */}
        {screen === 4 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 03 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">TRAINING EXPERIENCE</h2>
              <p className="text-zinc-400 text-sm mt-1">Helps set initial exercise complexity and volume.</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  How long have you been training?
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    "I don't train yet",
                    "Less than 6 months",
                    "6–12 months",
                    "1–2 years",
                    "2–5 years",
                    "5+ years"
                  ].map((dur) => (
                    <button
                      key={dur}
                      onClick={() => setTrainingDurationExperience(dur)}
                      className={`p-4 rounded-2xl border text-left font-bold text-sm transition-all flex items-center justify-between ${
                        trainingDurationExperience === dur
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900/90 text-zinc-200 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <span>{dur}</span>
                      {trainingDurationExperience === dur && <Check className="w-5 h-5 text-black" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-zinc-800/80">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  How would you describe your current level?
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['Beginner', 'Intermediate', 'Advanced'] as ExperienceLevel[]).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setExperience(lvl)}
                      className={`p-4 rounded-2xl border text-center font-bold text-sm transition-all ${
                        experience === lvl
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 5: PRIMARY GOAL */}
        {screen === 5 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 04 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">WHAT DO YOU WANT TO ACHIEVE?</h2>
              <p className="text-zinc-400 text-sm mt-1">Select your primary objective to define program structure.</p>
            </div>

            <div className="space-y-3">
              {[
                { title: 'BUILD MUSCLE', desc: 'Gain size and develop a stronger physique.', val: 'Build Muscle' },
                { title: 'LOSE FAT', desc: 'Reduce body fat while maintaining muscle.', val: 'Lose Fat' },
                { title: 'BUILD STRENGTH', desc: 'Improve performance on major lifts.', val: 'Increase Strength' },
                { title: 'RECOMPOSITION', desc: 'Build muscle while reducing body fat.', val: 'Improve Fitness' },
                { title: 'ATHLETIC PERFORMANCE', desc: 'Improve strength, conditioning and athletic ability.', val: 'Athletic Performance' },
              ].map((item) => (
                <button
                  key={item.val}
                  onClick={() => setGoal(item.val as FitnessGoal)}
                  className={`w-full p-5 rounded-2xl border text-left transition-all flex items-center justify-between group ${
                    goal === item.val
                      ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                      : 'bg-zinc-900/90 text-zinc-100 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div>
                    <h3 className="font-extrabold text-base tracking-wide uppercase">{item.title}</h3>
                    <p className={`text-xs mt-0.5 font-medium ${goal === item.val ? 'text-zinc-900' : 'text-zinc-400'}`}>
                      {item.desc}
                    </p>
                  </div>
                  {goal === item.val && <Check className="w-6 h-6 text-black flex-shrink-0" />}
                </button>
              ))}
            </div>

            <div className="pt-4 border-t border-zinc-800/80 space-y-3">
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wide">
                Secondary Goals (Optional)
              </label>
              <div className="flex flex-wrap gap-2">
                {['Build Strength', 'Burn Fat', 'Improve Mobility', 'Increase Stamina', 'Posture Alignment'].map((sg) => (
                  <button
                    key={sg}
                    onClick={() => toggleSecondaryGoal(sg)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all ${
                      secondaryGoals.includes(sg)
                        ? 'bg-zinc-100 text-black border-white'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {sg}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 6: PHYSIQUE PRIORITIES */}
        {screen === 6 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 05 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">WHICH AREAS DO YOU WANT TO DEVELOP MOST?</h2>
              <p className="text-zinc-400 text-sm mt-1">Select priority muscle groups for targeted volume allocation.</p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                'Chest', 'Back', 'Shoulders', 'Arms', 'Abs',
                'Glutes', 'Quads', 'Hamstrings', 'Calves', 'Overall physique',
                'No specific preference'
              ].map((area) => {
                const isSelected = physiquePriorities.includes(area);
                return (
                  <button
                    key={area}
                    onClick={() => togglePhysiquePriority(area)}
                    className={`p-4 rounded-2xl border font-bold text-sm transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                        : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <span>{area}</span>
                    {isSelected && <Check className="w-4 h-4 text-black flex-shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* SCREEN 7: TRAINING FREQUENCY & DURATION */}
        {screen === 7 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 06 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">TRAINING FREQUENCY</h2>
              <p className="text-zinc-400 text-sm mt-1">Customize your weekly schedule commitment.</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  HOW MANY DAYS CAN YOU TRAIN?
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                  {[2, 3, 4, 5, 6, 7].map((num) => (
                    <button
                      key={num}
                      onClick={() => setTrainingDaysPerWeek(num)}
                      className={`p-4 rounded-2xl border text-center font-extrabold text-lg transition-all ${
                        trainingDaysPerWeek === num
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {num} Days
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3 pt-6 border-t border-zinc-800/80">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  HOW LONG CAN YOU TRAIN EACH SESSION?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {[20, 30, 45, 60, 75, 90].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setPreferredDurationMin(mins)}
                      className={`p-4 rounded-2xl border text-center font-bold text-sm transition-all ${
                        preferredDurationMin === mins
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {mins === 90 ? '90+ minutes' : `${mins} minutes`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 8: EQUIPMENT & ENVIRONMENT */}
        {screen === 8 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 07 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">WHERE & HOW YOU TRAIN</h2>
              <p className="text-zinc-400 text-sm mt-1">We filter exercises strictly by available gym equipment.</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  WHERE DO YOU TRAIN?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {(['Full Gym', 'Home Gym', 'Home', 'Outdoor', 'Mixed'] as const).map((loc) => (
                    <button
                      key={loc}
                      onClick={() => setLocation(loc)}
                      className={`p-4 rounded-2xl border font-bold text-sm transition-all ${
                        location === loc
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {loc}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3 pt-6 border-t border-zinc-800/80">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  AVAILABLE EQUIPMENT (SELECT ALL THAT APPLY)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    'Barbell', 'Dumbbells', 'Bench', 'Squat Rack',
                    'Cable Machine', 'Machines', 'Pull-up Bar',
                    'Resistance Bands', 'Cardio Equipment', 'No Equipment'
                  ].map((eq) => {
                    const isSel = availableEquipmentList.includes(eq);
                    return (
                      <button
                        key={eq}
                        onClick={() => toggleEquipment(eq)}
                        className={`p-3.5 rounded-xl border font-bold text-xs transition-all flex items-center justify-between ${
                          isSel
                            ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                            : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:border-zinc-700'
                        }`}
                      >
                        <span>{eq}</span>
                        {isSel && <Check className="w-3.5 h-3.5 text-black" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 9: TRAINING PREFERENCES & INTENSITY */}
        {screen === 9 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 08 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">TRAINING PREFERENCES</h2>
              <p className="text-zinc-400 text-sm mt-1">Select exercise styles and your target intensity level.</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  WHAT TYPE OF TRAINING DO YOU ENJOY?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {[
                    'Bodybuilding', 'Strength Training', 'HIIT',
                    'Functional Training', 'Calisthenics', 'Cardio', 'Athletic Training'
                  ].map((tt) => {
                    const isSel = preferredTrainingTypes.includes(tt);
                    return (
                      <button
                        key={tt}
                        onClick={() => toggleTrainingType(tt)}
                        className={`p-4 rounded-2xl border font-bold text-sm transition-all flex items-center justify-between ${
                          isSel
                            ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                            : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                        }`}
                      >
                        <span>{tt}</span>
                        {isSel && <Check className="w-4 h-4 text-black" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-3 pt-6 border-t border-zinc-800/80">
                <label className="block text-sm font-bold text-zinc-200 uppercase tracking-wide">
                  HOW HARD DO YOU WANT YOUR TRAINING TO FEEL?
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['Moderate', 'Challenging', 'Very Intense'] as const).map((intensity) => (
                    <button
                      key={intensity}
                      onClick={() => setPerceivedIntensity(intensity)}
                      className={`p-4 rounded-2xl border text-center font-bold text-sm transition-all ${
                        perceivedIntensity === intensity
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {intensity}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-zinc-500 italic">
                  Note: "Very Intense" provides higher set volume while respecting recovery safety.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 10: LIFESTYLE & SLEEP */}
        {screen === 10 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 09 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">LIFESTYLE & RECOVERY</h2>
              <p className="text-zinc-400 text-sm mt-1">Non-gym activity dictates non-exercise energy expenditure (NEAT).</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wide">
                  HOW ACTIVE ARE YOU OUTSIDE THE GYM?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['Mostly sedentary', 'Lightly active', 'Moderately active', 'Very active'] as const).map((act) => (
                    <button
                      key={act}
                      onClick={() => setOutsideActivity(act)}
                      className={`p-3 rounded-xl border font-bold text-xs transition-all ${
                        outsideActivity === act
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {act}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wide">
                  AVERAGE DAILY STEPS
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {['Under 3,000', '3,000–5,000', '5,000–8,000', '8,000–10,000', '10,000+'].map((steps) => (
                    <button
                      key={steps}
                      onClick={() => setDailySteps(steps)}
                      className={`p-3 rounded-xl border font-bold text-xs transition-all ${
                        dailySteps === steps
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {steps}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wide">
                  SLEEP DURATION
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {['Under 5 hours', '5–6 hours', '6–7 hours', '7–8 hours', '8+ hours'].map((sleep) => (
                    <button
                      key={sleep}
                      onClick={() => setSleepDuration(sleep)}
                      className={`p-3 rounded-xl border font-bold text-xs transition-all ${
                        sleepDuration === sleep
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {sleep}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wide">
                  WORK/LIFE ACTIVITY
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Desk-based', 'Mixed', 'Physically active'] as const).map((wl) => (
                    <button
                      key={wl}
                      onClick={() => setWorkLifeActivity(wl)}
                      className={`p-3 rounded-xl border font-bold text-xs transition-all ${
                        workLifeActivity === wl
                          ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                          : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      {wl}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 11: WORKOUT SPLIT PREFERENCES */}
        {screen === 11 && (
          <div className="space-y-8 animate-fade-in">
            <div>
              <span className="text-xs font-mono text-[#D4FF44] font-bold tracking-widest uppercase">SECTION 10 / 10</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight mt-1">WHICH SPLIT DO YOU PREFER?</h2>
              <p className="text-zinc-400 text-sm mt-1">Choose how your training days are organized throughout the week.</p>
            </div>

            <div className="space-y-3">
              {[
                { title: 'Full Body', desc: 'Train all major muscle groups each session. Great for 2–3 days/week.' },
                { title: 'Upper / Lower', desc: 'Alternate between upper body and lower body workouts. Ideal for 4 days/week.' },
                { title: 'Push / Pull / Legs', desc: 'Chest/Delts/Triceps, Back/Biceps, Legs/Abs split. Exceptional for 3–6 days.' },
                { title: 'Body-Part Split', desc: 'Classic bodybuilding focus on 1–2 specific muscle groups per workout.' },
                { title: 'Let INTENSIVE decide', desc: 'INTENSIVE selects the optimal split structure based on your goals & equipment.' },
              ].map((sp) => (
                <button
                  key={sp.title}
                  onClick={() => setPreferredSplit(sp.title as any)}
                  className={`w-full p-5 rounded-2xl border text-left transition-all flex items-center justify-between ${
                    preferredSplit === sp.title
                      ? 'bg-[#D4FF44] text-black border-[#D4FF44]'
                      : 'bg-zinc-900 text-zinc-200 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div>
                    <h3 className="font-extrabold text-base uppercase">{sp.title}</h3>
                    <p className={`text-xs mt-0.5 ${preferredSplit === sp.title ? 'text-zinc-900 font-semibold' : 'text-zinc-400'}`}>
                      {sp.desc}
                    </p>
                  </div>
                  {preferredSplit === sp.title && <Check className="w-5 h-5 text-black flex-shrink-0" />}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* SCREEN 12: PERSONALIZED PLAN */}
        {screen === 12 && (
          <div className="space-y-8 animate-fade-in py-4">
            <div className="text-center space-y-2">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-[#D4FF44]/10 border border-[#D4FF44]/30 text-[#D4FF44] text-xs font-mono font-bold tracking-widest uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>PROGRAM GENERATION COMPLETE</span>
              </div>
              <h2 className="text-4xl sm:text-5xl font-black text-white uppercase italic tracking-tight font-display">
                YOUR INTENSIVE PLAN
              </h2>
            </div>

            {/* Athlete Summary Card */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 space-y-6">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase">{name}</h3>
                  <p className="text-xs text-zinc-400 font-mono">
                    {age} YEARS • {heightCm} CM • {weightKg} KG
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-zinc-500 font-bold block uppercase">TARGET</span>
                  <span className="text-lg font-black text-[#D4FF44]">{targetWeightKg} KG</span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800">
                  <span className="text-zinc-500 font-bold block uppercase">GOAL</span>
                  <span className="text-white font-extrabold uppercase mt-0.5 block">{goal}</span>
                </div>
                <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800">
                  <span className="text-zinc-500 font-bold block uppercase">EXPERIENCE</span>
                  <span className="text-white font-extrabold uppercase mt-0.5 block">{experience}</span>
                </div>
                <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800">
                  <span className="text-zinc-500 font-bold block uppercase">TRAINING</span>
                  <span className="text-white font-extrabold uppercase mt-0.5 block">{trainingDaysPerWeek} DAYS / WK</span>
                </div>
                <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800">
                  <span className="text-zinc-500 font-bold block uppercase">SESSION</span>
                  <span className="text-white font-extrabold uppercase mt-0.5 block">{preferredDurationMin} MIN</span>
                </div>
              </div>

              {/* Recommended Program Card */}
              <div className="bg-gradient-to-br from-zinc-900 to-black border-2 border-[#D4FF44]/40 rounded-2xl p-5 space-y-3 relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-[#D4FF44] text-black text-[10px] font-black uppercase px-3 py-1 rounded-bl-xl tracking-wider">
                  RECOMMENDED PROTOCOL
                </div>
                <span className="text-xs font-mono text-[#D4FF44] font-bold uppercase tracking-widest">
                  12-WEEK HYPERTROPHY
                </span>
                <h4 className="text-2xl font-black text-white uppercase italic">
                  12-WEEK MUSCLE BUILDER
                </h4>
                <div className="flex flex-wrap gap-2 text-xs font-bold text-zinc-300">
                  <span className="bg-zinc-800 px-3 py-1 rounded-lg">{trainingDaysPerWeek} DAYS / WEEK</span>
                  <span className="bg-zinc-800 px-3 py-1 rounded-lg">{preferredDurationMin} MIN / SESSION</span>
                  <span className="bg-zinc-800 px-3 py-1 rounded-lg">{finalSplit.toUpperCase()} SPLIT</span>
                </div>
              </div>

              {/* Calorie & Protein Targets */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wider">ESTIMATED NUTRITION TARGETS</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-zinc-500 font-bold block">CALORIE TARGET</span>
                      <span className="text-xl font-black text-white">{estimates.calories} <span className="text-xs font-normal text-zinc-400">kcal/day</span></span>
                    </div>
                    <Flame className="w-6 h-6 text-amber-500" />
                  </div>
                  <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-zinc-500 font-bold block">PROTEIN TARGET</span>
                      <span className="text-xl font-black text-[#D4FF44]">{estimates.protein} <span className="text-xs font-normal text-zinc-400">g/day</span></span>
                    </div>
                    <Zap className="w-6 h-6 text-[#D4FF44]" />
                  </div>
                </div>
                <p className="text-[11px] text-zinc-500 italic">
                  * Nutritional values are general fitness estimates based on your metrics, not medical advice.
                </p>
              </div>

              {/* Generated Schedule Preview */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wider">YOUR WEEKLY TRAINING SPLIT</h4>
                <div className="space-y-2">
                  {getDynamicWeeklySchedule().map((item, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border flex items-center justify-between text-xs font-semibold ${
                        item.rest
                          ? 'bg-zinc-950/60 border-zinc-800/60 text-zinc-500'
                          : 'bg-zinc-900 border-zinc-800 text-white'
                      }`}
                    >
                      <span className="font-mono text-zinc-400 w-24 font-bold">{item.day}</span>
                      <span className={`font-bold flex-1 uppercase ${item.rest ? 'text-zinc-500' : 'text-[#D4FF44]'}`}>
                        {item.title}
                      </span>
                      <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-zinc-800/80 text-zinc-400">
                        {item.rest ? 'REST' : `${preferredDurationMin} MIN`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={handleCompleteProgram}
              className="w-full bg-[#D4FF44] hover:bg-[#c3f033] text-black font-black text-lg uppercase py-5 px-6 rounded-2xl transition-all shadow-xl shadow-[#D4FF44]/20 flex items-center justify-center space-x-3 group"
            >
              <span>START MY PROGRAM</span>
              <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        )}
      </div>

      {/* Bottom Action Footer for Screens 2 - 11 */}
      {screen > 1 && screen < 12 && (
        <div className="sticky bottom-0 z-30 bg-[#0A0A0B]/90 backdrop-blur-md border-t border-zinc-800/80 px-4 py-4 sm:px-8">
          <div className="max-w-3xl mx-auto flex items-center justify-between">
            <button
              onClick={() => setScreen(screen - 1)}
              className="text-zinc-400 hover:text-white font-bold text-sm uppercase transition-colors px-4 py-2"
            >
              PREVIOUS
            </button>

            <button
              onClick={() => setScreen(screen + 1)}
              className="bg-[#D4FF44] hover:bg-[#c3f033] text-black font-extrabold text-sm uppercase py-3.5 px-8 rounded-xl transition-all flex items-center space-x-2 shadow-lg shadow-[#D4FF44]/10"
            >
              <span>CONTINUE</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
