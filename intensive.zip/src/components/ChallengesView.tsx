import React, { useState } from 'react';
import { CheckCircle2, Plus, Clock } from 'lucide-react';
import { Challenge } from '../types/fitness';
import { storage } from '../services/storage';

export const ChallengesView: React.FC = () => {
  const [challenges, setChallenges] = useState<Challenge[]>(storage.getChallenges());

  const handleLogProgress = (id: string) => {
    storage.updateChallengeProgress(id, 1);
    setChallenges(storage.getChallenges());
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Title */}
      <div className="border-b border-[#1F1F22] pb-6">
        <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">Fitness Challenges</h1>
        <p className="text-[#666] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-medium">
          Push past mental boundaries with high-intensity structured challenges.
        </p>
      </div>

      {/* CHALLENGES GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {challenges.map((c) => {
          const pct = Math.min(100, Math.round((c.currentValue / c.targetValue) * 100));

          return (
            <div
              key={c.id}
              className={`p-6 rounded-3xl border transition-all relative overflow-hidden ${
                c.isCompleted
                  ? 'bg-[#161618] border-[#D4FF44]/40'
                  : 'bg-[#161618] border-[#1F1F22] hover:border-[#333]'
              }`}
            >
              {c.isCompleted && (
                <div className="absolute top-4 right-4 bg-[#D4FF44] text-black font-black text-[9px] uppercase px-2.5 py-1 rounded-md flex items-center gap-1 tracking-widest">
                  <CheckCircle2 className="w-3.5 h-3.5" /> COMPLETED
                </div>
              )}

              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-[#D4FF44] mb-2">
                {c.category}
              </div>

              <h3 className="text-xl font-black text-white uppercase tracking-tight mb-1">{c.title}</h3>
              <p className="text-xs text-[#666] font-medium mb-6 leading-relaxed">{c.description}</p>

              {/* Progress Bar */}
              <div className="space-y-2 mb-6">
                <div className="flex items-center justify-between text-xs font-black uppercase tracking-wider">
                  <span className="text-[#EAEAEA]">
                    {c.currentValue} / {c.targetValue} {c.unit}
                  </span>
                  <span className="text-[#D4FF44]">{pct}%</span>
                </div>
                <div className="w-full bg-[#0A0A0B] h-2.5 rounded-full overflow-hidden border border-[#222]">
                  <div
                    className="h-full bg-[#D4FF44] transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-[#222]">
                <div className="text-[10px] text-[#666] font-bold uppercase tracking-widest flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#666]" />
                  <span>{c.daysRemaining} DAYS REMAINING</span>
                </div>

                {!c.isCompleted && (
                  <button
                    onClick={() => handleLogProgress(c.id)}
                    className="flex items-center gap-1.5 bg-[#D4FF44]/10 hover:bg-[#D4FF44] text-[#D4FF44] hover:text-black font-black text-[10px] uppercase tracking-wider px-4 py-2 rounded-xl border border-[#D4FF44]/20 transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>LOG PROGRESS</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
