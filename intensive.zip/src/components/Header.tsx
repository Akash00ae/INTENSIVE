import React, { useState, useEffect } from 'react';
import { Flame, Dumbbell, Sparkles, Download } from 'lucide-react';
import { storage } from '../services/storage';

interface HeaderProps {
  onOpenAICoach: () => void;
  onStartTodayWorkout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAICoach, onStartTodayWorkout }) => {
  const [streakDays, setStreakDays] = useState(12);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const updateHeader = () => {
      const profile = storage.getProfile();
      setStreakDays(profile.streakDays || 12);
    };

    updateHeader();
    window.addEventListener('mk_storage_updated', updateHeader);

    // PWA Install prompt listener
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    return () => {
      window.removeEventListener('mk_storage_updated', updateHeader);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-[#0A0A0B]/95 backdrop-blur-md border-b border-[#1F1F22] px-4 py-3 sm:px-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#D4FF44] flex items-center justify-center font-black text-black text-xl tracking-tighter">
            MK
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black tracking-tighter text-[#EAEAEA] text-lg font-sans">MK <span className="text-[#D4FF44]">FITNESS</span></span>
              <span className="text-[9px] uppercase font-bold tracking-[0.2em] bg-[#1F1F22] text-[#888] px-1.5 py-0.5 rounded border border-[#333]">
                INTENSIVE
              </span>
            </div>
            <p className="text-[10px] text-[#666] tracking-[0.15em] font-bold uppercase hidden sm:block">
              CONSISTENCY CREATES RESULTS.
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Streak Badge */}
          <div className="flex items-center gap-1.5 bg-[#161618] border border-[#1F1F22] px-3 py-1.5 rounded-full text-xs font-bold text-[#D4FF44]" title="Weekly Workout Streak">
            <Flame className="w-4 h-4 text-[#D4FF44] fill-[#D4FF44]" />
            <span>{streakDays} Weeks Streak</span>
          </div>

          {/* AI Coach Quick Launch Button */}
          <button
            onClick={onOpenAICoach}
            className="flex items-center gap-1.5 bg-[#161618] hover:bg-[#222] border border-[#1F1F22] text-xs font-bold text-white px-3.5 py-1.5 rounded-full transition-all uppercase tracking-wider"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#D4FF44]" />
            <span className="hidden sm:inline">AI Coach</span>
          </button>

          {/* Quick Start Workout Button */}
          <button
            onClick={onStartTodayWorkout}
            className="flex items-center gap-1.5 bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs px-4 py-1.5 rounded-full shadow-lg shadow-[#D4FF44]/10 transition-all uppercase tracking-wider active:scale-95"
          >
            <Dumbbell className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Start Workout</span>
          </button>

          {/* PWA Install Button if available */}
          {deferredPrompt && (
            <button
              onClick={handleInstallClick}
              className="p-1.5 bg-[#161618] hover:bg-[#222] text-[#D4FF44] border border-[#1F1F22] rounded-full transition-all"
              title="Add to Home Screen"
            >
              <Download className="w-4 h-4" />
            </button>
          )}

        </div>

      </div>
    </header>
  );
};
