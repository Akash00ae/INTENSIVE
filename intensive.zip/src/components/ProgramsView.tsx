import React, { useState } from 'react';
import { CheckCircle2, ArrowRight, Play } from 'lucide-react';
import { TrainingProgram, Workout } from '../types/fitness';
import { SAMPLE_PROGRAMS, SAMPLE_WORKOUTS } from '../data/initialData';
import { storage } from '../services/storage';

interface ProgramsViewProps {
  onStartWorkout: (workout: Workout) => void;
}

export const ProgramsView: React.FC<ProgramsViewProps> = ({ onStartWorkout }) => {
  const [selectedProgram, setSelectedProgram] = useState<TrainingProgram>(SAMPLE_PROGRAMS[1]); // Default 6-Week Muscle Builder
  const [activeProgramId, setActiveProgramId] = useState<string>(
    storage.getProfile().currentProgramId || 'prog-6wk-muscle'
  );

  const handleEnrollProgram = (programId: string) => {
    const profile = storage.getProfile();
    profile.currentProgramId = programId;
    storage.saveProfile(profile);
    setActiveProgramId(programId);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Header */}
      <div className="border-b border-[#1F1F22] pb-6">
        <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">Structured Programs</h1>
        <p className="text-[#666] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-medium">
          Periodized training protocols designed for progressive physical overload.
        </p>
      </div>

      {/* Program Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {SAMPLE_PROGRAMS.map((program) => {
          const isEnrolled = activeProgramId === program.id;
          const isSelected = selectedProgram.id === program.id;
          return (
            <button
              key={program.id}
              onClick={() => setSelectedProgram(program)}
              className={`p-4 rounded-2xl border text-left transition-all relative cursor-pointer ${
                isSelected
                  ? 'bg-[#161618] border-[#D4FF44] text-white font-bold'
                  : 'bg-[#161618] border-[#1F1F22] text-[#888] hover:border-[#333]'
              }`}
            >
              {isEnrolled && (
                <span className="absolute top-3 right-3 text-[9px] font-black uppercase bg-[#D4FF44]/20 text-[#D4FF44] border border-[#D4FF44]/30 px-1.5 py-0.5 rounded tracking-widest">
                  ENROLLED
                </span>
              )}
              <div className="text-[10px] font-black uppercase tracking-widest text-[#D4FF44] mb-1">{program.goal}</div>
              <div className="font-black text-xs text-white uppercase line-clamp-1">{program.title}</div>
              <div className="text-[10px] text-[#666] mt-2 font-bold uppercase tracking-wider">
                {program.daysPerWeek} DAYS/WK • {program.durationMinutes}M
              </div>
            </button>
          );
        })}
      </div>

      {/* PROGRAM DETAIL VIEW */}
      <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl p-6 sm:p-8 shadow-2xl">
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-[#222]">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="px-2.5 py-1 bg-[#D4FF44]/10 text-[#D4FF44] border border-[#D4FF44]/20 font-black text-[10px] uppercase tracking-wider rounded-md">
                {selectedProgram.goal}
              </span>
              <span className="px-2.5 py-1 bg-[#0A0A0B] text-[#888] font-bold text-[10px] uppercase tracking-wider border border-[#222] rounded-md">
                {selectedProgram.difficulty}
              </span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
              {selectedProgram.title}
            </h2>
            <p className="text-[#D4FF44] font-bold text-xs uppercase tracking-widest mt-1">{selectedProgram.tagline}</p>
            <p className="text-[#888] text-xs sm:text-sm mt-3 max-w-3xl leading-relaxed font-medium">{selectedProgram.description}</p>
          </div>

          {/* Enroll / Start Program CTA */}
          <div className="shrink-0 flex flex-col gap-2">
            {activeProgramId === selectedProgram.id ? (
              <div className="flex items-center gap-2 bg-[#D4FF44]/10 border border-[#D4FF44]/30 text-[#D4FF44] font-black text-xs px-6 py-3.5 rounded-2xl justify-center tracking-widest uppercase">
                <CheckCircle2 className="w-4 h-4" />
                <span>CURRENTLY ACTIVE</span>
              </div>
            ) : (
              <button
                onClick={() => handleEnrollProgram(selectedProgram.id)}
                className="flex items-center justify-center gap-2 bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs px-8 py-3.5 rounded-2xl uppercase tracking-widest transition-colors cursor-pointer shadow-xl"
              >
                <span>ENROLL IN PROGRAM</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Program Key Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-6">
          <div className="bg-[#0A0A0B] p-4 rounded-2xl border border-[#222]">
            <span className="text-[9px] font-bold text-[#666] uppercase tracking-[0.2em] block">Duration</span>
            <span className="text-base font-black text-white uppercase mt-1 block">{selectedProgram.durationWeeks} Weeks</span>
          </div>
          <div className="bg-[#0A0A0B] p-4 rounded-2xl border border-[#222]">
            <span className="text-[9px] font-bold text-[#666] uppercase tracking-[0.2em] block">Weekly Frequency</span>
            <span className="text-base font-black text-white uppercase mt-1 block">{selectedProgram.daysPerWeek} Days / Wk</span>
          </div>
          <div className="bg-[#0A0A0B] p-4 rounded-2xl border border-[#222]">
            <span className="text-[9px] font-bold text-[#666] uppercase tracking-[0.2em] block">Session Length</span>
            <span className="text-base font-black text-white uppercase mt-1 block">{selectedProgram.durationMinutes} Minutes</span>
          </div>
          <div className="bg-[#0A0A0B] p-4 rounded-2xl border border-[#222]">
            <span className="text-[9px] font-bold text-[#666] uppercase tracking-[0.2em] block">Equipment</span>
            <span className="text-base font-black text-[#D4FF44] uppercase mt-1 block">{selectedProgram.equipment}</span>
          </div>
        </div>

        {/* Weekly Schedule Breakdown */}
        <div>
          <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[#888] mb-4">Weekly Schedule Breakdown</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
            {selectedProgram.weeklySchedule.map((day) => {
              const matchingWorkout = day.workoutId
                ? SAMPLE_WORKOUTS.find(w => w.id === day.workoutId)
                : undefined;

              return (
                <div
                  key={day.dayNumber}
                  className={`p-4 rounded-2xl border flex flex-col justify-between ${
                    day.isRestDay
                      ? 'bg-[#0A0A0B]/60 border-[#222] text-[#444]'
                      : 'bg-[#0A0A0B] border-[#222] text-white'
                  }`}
                >
                  <div>
                    <span className="text-[9px] font-black text-[#D4FF44] uppercase tracking-widest block mb-1">
                      DAY {day.dayNumber}
                    </span>
                    <h4 className="font-bold text-xs text-[#EAEAEA] uppercase line-clamp-2">{day.title}</h4>
                  </div>

                  {!day.isRestDay && matchingWorkout && (
                    <button
                      onClick={() => onStartWorkout(matchingWorkout)}
                      className="mt-4 flex items-center justify-center gap-1 bg-white hover:bg-[#D4FF44] text-black font-black text-[10px] py-2.5 rounded-xl uppercase tracking-widest transition-colors cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Start</span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
