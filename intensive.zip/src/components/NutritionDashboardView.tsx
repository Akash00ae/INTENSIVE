import React, { useState } from 'react';
import { Plus, Utensils, Droplets, Trash2, Search } from 'lucide-react';
import { MealLog, FoodItem } from '../types/fitness';
import { storage } from '../services/storage';

export const NutritionDashboardView: React.FC = () => {
  const [todayStr] = useState<string>(new Date().toISOString().split('T')[0]);
  const [mealLogs, setMealLogs] = useState<MealLog[]>(storage.getMealLogs(todayStr));
  const [waterLiters, setWaterLiters] = useState<number>(storage.getWaterLog(todayStr));

  // Modals state
  const [isAddMealOpen, setIsAddMealOpen] = useState(false);
  const [isAddCustomFoodOpen, setIsAddCustomFoodOpen] = useState(false);

  // Search & Selector in Add Meal Modal
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMealType, setSelectedMealType] = useState<'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks'>('Lunch');
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const [servings, setServings] = useState<number>(1);

  // New Food Form State
  const [customFoodName, setCustomFoodName] = useState('');
  const [customCalories, setCustomCalories] = useState(200);
  const [customProtein, setCustomProtein] = useState(15);
  const [customCarbs, setCustomCarbs] = useState(20);
  const [customFat, setCustomFat] = useState(5);

  const foodDatabase = storage.getFoodItems();

  // Calculate Macros Totals
  const totalCalories = mealLogs.reduce((acc, m) => acc + m.calories, 0);
  const totalProtein = mealLogs.reduce((acc, m) => acc + m.proteinG, 0);
  const totalCarbs = mealLogs.reduce((acc, m) => acc + m.carbsG, 0);
  const totalFat = mealLogs.reduce((acc, m) => acc + m.fatG, 0);

  // Target Defaults
  const targetCalories = 2500;
  const targetProtein = 170;
  const targetCarbs = 280;
  const targetFat = 75;
  const targetWater = 3.0;

  const handleAddWater = (amount: number) => {
    storage.addWater(amount, todayStr);
    setWaterLiters(storage.getWaterLog(todayStr));
  };

  const handleLogMeal = () => {
    if (!selectedFood) return;

    storage.addMealLog({
      mealType: selectedMealType,
      foodName: selectedFood.name,
      servings,
      calories: Math.round(selectedFood.calories * servings),
      proteinG: Math.round(selectedFood.proteinG * servings),
      carbsG: Math.round(selectedFood.carbsG * servings),
      fatG: Math.round(selectedFood.fatG * servings),
    });

    setMealLogs(storage.getMealLogs(todayStr));
    setIsAddMealOpen(false);
    setSelectedFood(null);
  };

  const handleSaveCustomFood = () => {
    if (!customFoodName) return;

    storage.addCustomFoodItem({
      name: customFoodName,
      category: 'Indian',
      servingSize: '1 portion',
      calories: customCalories,
      proteinG: customProtein,
      carbsG: customCarbs,
      fatG: customFat,
    });

    setIsAddCustomFoodOpen(false);
    setCustomFoodName('');
  };

  const handleDeleteMeal = (id: string) => {
    storage.deleteMealLog(id);
    setMealLogs(storage.getMealLogs(todayStr));
  };

  const filteredFoods = foodDatabase.filter((f) =>
    f.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Title & Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1F1F22] pb-6">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">Nutrition & Macros</h1>
          <p className="text-[#666] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-medium">
            Caloric balance, macronutrient targets, and daily hydration logging.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAddCustomFoodOpen(true)}
            className="flex items-center gap-1.5 bg-[#161618] border border-[#1F1F22] hover:bg-[#222] text-[#EAEAEA] font-bold text-xs px-4 py-3 rounded-2xl transition-all uppercase tracking-wider cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>ADD FOOD</span>
          </button>

          <button
            onClick={() => setIsAddMealOpen(true)}
            className="flex items-center gap-2 bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs px-5 py-3 rounded-2xl uppercase tracking-widest transition-colors cursor-pointer shadow-xl shrink-0"
          >
            <Utensils className="w-4 h-4" />
            <span>LOG MEAL</span>
          </button>
        </div>
      </div>

      {/* MACRO TARGETS DASHBOARD */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* Calories Card */}
        <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-3xl lg:col-span-1">
          <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Calories</div>
          <div className="text-2xl font-black text-white uppercase">
            {totalCalories.toLocaleString()} <span className="text-xs text-[#666] font-bold">/ {targetCalories} kcal</span>
          </div>
          <div className="w-full bg-[#0A0A0B] h-2 rounded-full mt-3 overflow-hidden border border-[#222]">
            <div
              className="bg-[#D4FF44] h-full transition-all"
              style={{ width: `${Math.min(100, (totalCalories / targetCalories) * 100)}%` }}
            />
          </div>
        </div>

        {/* Protein Card */}
        <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-3xl">
          <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Protein</div>
          <div className="text-2xl font-black text-white uppercase">
            {totalProtein} <span className="text-xs text-[#666] font-bold">/ {targetProtein} g</span>
          </div>
          <div className="w-full bg-[#0A0A0B] h-2 rounded-full mt-3 overflow-hidden border border-[#222]">
            <div
              className="bg-[#D4FF44] h-full transition-all"
              style={{ width: `${Math.min(100, (totalProtein / targetProtein) * 100)}%` }}
            />
          </div>
        </div>

        {/* Carbohydrates Card */}
        <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-3xl">
          <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Carbohydrates</div>
          <div className="text-2xl font-black text-white uppercase">
            {totalCarbs} <span className="text-xs text-[#666] font-bold">/ {targetCarbs} g</span>
          </div>
          <div className="w-full bg-[#0A0A0B] h-2 rounded-full mt-3 overflow-hidden border border-[#222]">
            <div
              className="bg-[#888] h-full transition-all"
              style={{ width: `${Math.min(100, (totalCarbs / targetCarbs) * 100)}%` }}
            />
          </div>
        </div>

        {/* Fat Card */}
        <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-3xl">
          <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Fat</div>
          <div className="text-2xl font-black text-white uppercase">
            {totalFat} <span className="text-xs text-[#666] font-bold">/ {targetFat} g</span>
          </div>
          <div className="w-full bg-[#0A0A0B] h-2 rounded-full mt-3 overflow-hidden border border-[#222]">
            <div
              className="bg-[#666] h-full transition-all"
              style={{ width: `${Math.min(100, (totalFat / targetFat) * 100)}%` }}
            />
          </div>
        </div>

        {/* Water Intake Card */}
        <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-3xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">
              <span>Water</span>
              <Droplets className="w-4 h-4 text-[#D4FF44]" />
            </div>
            <div className="text-2xl font-black text-white uppercase">
              {waterLiters} <span className="text-xs text-[#666] font-bold">/ {targetWater} L</span>
            </div>
          </div>

          <div className="flex gap-2 mt-3">
            <button
              onClick={() => handleAddWater(0.25)}
              className="flex-1 bg-[#0A0A0B] hover:bg-[#222] border border-[#222] text-[#D4FF44] font-bold text-[10px] py-1.5 rounded-xl uppercase tracking-wider transition-all cursor-pointer"
            >
              +250 ml
            </button>
            <button
              onClick={() => handleAddWater(0.5)}
              className="flex-1 bg-[#0A0A0B] hover:bg-[#222] border border-[#222] text-[#D4FF44] font-bold text-[10px] py-1.5 rounded-xl uppercase tracking-wider transition-all cursor-pointer"
            >
              +500 ml
            </button>
          </div>
        </div>

      </div>

      {/* TODAY'S MEAL LOGS LIST */}
      <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl p-6">
        <h3 className="text-xs font-black text-[#888] uppercase tracking-[0.2em] mb-4">Today's Logged Meals</h3>
        {mealLogs.length === 0 ? (
          <div className="text-center py-8 text-[#666] text-xs font-bold uppercase tracking-wider">
            No meals logged yet today. Click "LOG MEAL" to record macros.
          </div>
        ) : (
          <div className="space-y-3">
            {mealLogs.map((meal) => (
              <div
                key={meal.id}
                className="p-4 bg-[#0A0A0B] rounded-2xl border border-[#222] flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-[9px] font-black uppercase bg-[#D4FF44]/10 text-[#D4FF44] px-2 py-0.5 rounded border border-[#D4FF44]/20 tracking-wider">
                      {meal.mealType}
                    </span>
                    <span className="font-black text-xs text-white uppercase">{meal.foodName}</span>
                  </div>
                  <div className="text-[10px] text-[#666] font-bold uppercase mt-1">
                    {meal.servings} serving(s) • P: {meal.proteinG}g | C: {meal.carbsG}g | F: {meal.fatG}g
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-xs font-black text-[#D4FF44] uppercase">{meal.calories} kcal</span>
                  <button
                    onClick={() => handleDeleteMeal(meal.id)}
                    className="text-[#666] hover:text-red-400 p-1.5 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ADD MEAL MODAL */}
      {isAddMealOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6">
            
            <div className="flex items-center justify-between border-b border-[#222] pb-4">
              <h3 className="text-lg font-black text-white uppercase tracking-wider">Log Meal Entry</h3>
              <button onClick={() => setIsAddMealOpen(false)} className="text-[#666] hover:text-white cursor-pointer text-sm font-bold">✕</button>
            </div>

            {/* Meal Type Selection */}
            <div className="grid grid-cols-4 gap-2">
              {(['Breakfast', 'Lunch', 'Dinner', 'Snacks'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setSelectedMealType(type)}
                  className={`py-2 rounded-xl text-[10px] font-black uppercase tracking-wider cursor-pointer transition-all ${
                    selectedMealType === type
                      ? 'bg-[#D4FF44] text-black'
                      : 'bg-[#0A0A0B] text-[#888] border border-[#222] hover:bg-[#222]'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            {/* Search Food Database */}
            <div className="relative">
              <Search className="w-4 h-4 text-[#666] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search food database..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl pl-10 pr-4 py-2.5 text-xs font-bold text-white focus:border-[#D4FF44] outline-none"
              />
            </div>

            {/* Food Selection Scroll list */}
            <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
              {filteredFoods.map((food) => (
                <button
                  key={food.id}
                  onClick={() => setSelectedFood(food)}
                  className={`w-full p-3 rounded-2xl border text-left transition-all flex items-center justify-between cursor-pointer ${
                    selectedFood?.id === food.id
                      ? 'bg-[#D4FF44]/10 border-[#D4FF44] text-[#D4FF44]'
                      : 'bg-[#0A0A0B] border-[#222] text-[#888] hover:border-[#333]'
                  }`}
                >
                  <div>
                    <div className="font-black text-xs text-white uppercase">{food.name}</div>
                    <div className="text-[10px] text-[#666] font-bold uppercase mt-0.5">
                      {food.servingSize} • P: {food.proteinG}g | C: {food.carbsG}g
                    </div>
                  </div>
                  <span className="text-xs font-black text-[#D4FF44] uppercase">{food.calories} kcal</span>
                </button>
              ))}
            </div>

            {selectedFood && (
              <div className="bg-[#0A0A0B] p-4 rounded-2xl border border-[#222] flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em]">Servings</span>
                <input
                  type="number"
                  min="0.5"
                  step="0.5"
                  value={servings}
                  onChange={(e) => setServings(parseFloat(e.target.value) || 1)}
                  className="w-20 bg-[#161618] border border-[#222] text-white font-bold text-center py-1.5 rounded-xl text-xs"
                />
              </div>
            )}

            <button
              onClick={handleLogMeal}
              disabled={!selectedFood}
              className="w-full bg-[#D4FF44] hover:bg-[#c2f033] disabled:opacity-40 text-black font-black text-xs py-4 rounded-2xl transition-colors uppercase tracking-widest shadow-xl cursor-pointer"
            >
              LOG MEAL TO DASHBOARD
            </button>
          </div>
        </div>
      )}

      {/* ADD CUSTOM FOOD ITEM MODAL */}
      {isAddCustomFoodOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6">
            
            <div className="flex items-center justify-between border-b border-[#222] pb-4">
              <h3 className="text-lg font-black text-white uppercase tracking-wider">Add Custom Food Item</h3>
              <button onClick={() => setIsAddCustomFoodOpen(false)} className="text-[#666] hover:text-white cursor-pointer text-sm font-bold">✕</button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Food Name</label>
                <input
                  type="text"
                  placeholder="e.g. Protein Smoothie"
                  value={customFoodName}
                  onChange={(e) => setCustomFoodName(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-4 py-2.5 text-white font-bold text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Calories (kcal)</label>
                  <input
                    type="number"
                    value={customCalories}
                    onChange={(e) => setCustomCalories(parseInt(e.target.value) || 0)}
                    className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3 py-2 text-white font-bold text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Protein (g)</label>
                  <input
                    type="number"
                    value={customProtein}
                    onChange={(e) => setCustomProtein(parseInt(e.target.value) || 0)}
                    className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3 py-2 text-white font-bold text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Carbs (g)</label>
                  <input
                    type="number"
                    value={customCarbs}
                    onChange={(e) => setCustomCarbs(parseInt(e.target.value) || 0)}
                    className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3 py-2 text-white font-bold text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Fat (g)</label>
                  <input
                    type="number"
                    value={customFat}
                    onChange={(e) => setCustomFat(parseInt(e.target.value) || 0)}
                    className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-3 py-2 text-white font-bold text-xs"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleSaveCustomFood}
              className="w-full bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs py-4 rounded-2xl transition-colors uppercase tracking-widest shadow-xl cursor-pointer"
            >
              SAVE FOOD TO DATABASE
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
