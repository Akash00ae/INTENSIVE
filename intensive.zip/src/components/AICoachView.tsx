import React, { useState } from 'react';
import { Send, Sparkles, Bot, User, Loader2 } from 'lucide-react';
import { ChatMessage } from '../types/fitness';
import { storage } from '../services/storage';

export const AICoachView: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm-1',
      sender: 'ai',
      text: "Welcome! I'm SR Abhishek, your INTENSIVE Head Coach. Synchronized with your progressive overload history and periodization split. How can I optimize your training protocol today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const profile = storage.getProfile();
  const logs = storage.getWorkoutLogs();

  const samplePrompts = [
    "My session time is cut to 30 mins today.",
    "My bench press plateaued at 80kg.",
    "I missed yesterday's leg day split.",
    "Optimal post-workout macronutrient intake?",
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          userProfile: profile,
          workoutContext: {
            recentLogsCount: logs.length,
            lastWorkout: logs[0]?.workoutTitle,
            lastWorkoutVolume: logs[0]?.totalVolumeKg,
          },
        }),
      });

      const data = await response.json();
      const aiReply = data.reply || "Focus on progressive mechanical tension and strict form across all working sets.";

      const aiMsg: ChatMessage = {
        id: 'msg-ai-' + Date.now(),
        sender: 'ai',
        text: aiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error('Error calling AI Coach:', error);
      const fallbackMsg: ChatMessage = {
        id: 'msg-err-' + Date.now(),
        sender: 'ai',
        text: "Stick to your scheduled workout today with strict focus on progressive overload and adequate recovery time.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12 flex flex-col h-[calc(100vh-140px)] min-h-[500px]">
      
      {/* Title */}
      <div className="border-b border-[#1F1F22] pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#D4FF44]" />
            <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">AI Coach — SR Abhishek</h1>
          </div>
          <p className="text-[#666] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-medium">
            Tactical strength analysis and real-time training optimizations powered by Gemini.
          </p>
        </div>

        {/* Coach Badge */}
        <div className="bg-[#161618] border border-[#1F1F22] p-3 rounded-2xl flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-full bg-[#D4FF44] flex items-center justify-center font-black text-black text-xs">
            SA
          </div>
          <div>
            <div className="text-xs font-black text-white uppercase">SR Abhishek</div>
            <div className="text-[10px] text-[#D4FF44] font-bold uppercase tracking-wider">INTENSIVE HEAD COACH</div>
          </div>
        </div>
      </div>

      {/* CHAT MESSAGES CANVAS */}
      <div className="flex-1 bg-[#161618] border border-[#1F1F22] rounded-3xl p-4 sm:p-6 overflow-y-auto space-y-4 shadow-xl">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 max-w-2xl ${msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
          >
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                msg.sender === 'user' ? 'bg-[#D4FF44] text-black font-black' : 'bg-[#0A0A0B] text-[#D4FF44] border border-[#222]'
              }`}
            >
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div
              className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-[#D4FF44] text-black font-black uppercase rounded-tr-none tracking-wider'
                  : 'bg-[#0A0A0B] text-[#EAEAEA] border border-[#222] font-medium rounded-tl-none'
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.text}</div>
              <div className={`text-[9px] font-bold mt-1 text-right uppercase tracking-widest ${msg.sender === 'user' ? 'text-black/60' : 'text-[#666]'}`}>
                {msg.timestamp}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-[#D4FF44] bg-[#0A0A0B] p-3.5 rounded-2xl border border-[#222] w-max">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Analyzing performance logs...</span>
          </div>
        )}
      </div>

      {/* QUICK PROMPT CHIPS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {samplePrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(prompt)}
            className="px-3.5 py-2 rounded-xl bg-[#161618] border border-[#1F1F22] hover:border-[#333] text-[10px] text-[#888] font-bold uppercase tracking-wider whitespace-nowrap transition-all shrink-0 cursor-pointer"
          >
            "{prompt}"
          </button>
        ))}
      </div>

      {/* INPUT FORM */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex items-center gap-2 bg-[#161618] p-2 rounded-2xl border border-[#1F1F22]"
      >
        <input
          type="text"
          placeholder="ASK AI COACH FOR TRAINING / DIET ADVICE..."
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          className="flex-1 bg-transparent px-4 py-2 text-xs font-bold uppercase tracking-wider text-white focus:outline-none placeholder-[#666]"
        />
        <button
          type="submit"
          disabled={!inputMessage.trim() || isLoading}
          className="p-3 bg-[#D4FF44] hover:bg-[#c2f033] disabled:opacity-40 text-black rounded-xl transition-colors font-black cursor-pointer"
        >
          <Send className="w-4 h-4 fill-black" />
        </button>
      </form>

    </div>
  );
};
