import React, { useState } from 'react';
import { Edit2, RotateCcw } from 'lucide-react';
import { UserProfile } from '../types/fitness';
import { storage } from '../services/storage';

interface ProfileViewProps {
  userProfile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onResetData: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ userProfile, onUpdateProfile, onResetData }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<UserProfile>({ ...userProfile });

  const prs = storage.getPRs();
  const logs = storage.getWorkoutLogs();
  const totalVolume = logs.reduce((acc, l) => acc + (l.totalVolumeKg || 0), 0) + 42800;

  const handleSave = () => {
    storage.saveProfile(formData);
    onUpdateProfile(formData);
    setIsEditing(false);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Profile Header Card */}
      <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden shadow-xl">
        <div className="flex items-center gap-5 relative z-10">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#0A0A0B] border-2 border-[#D4FF44] flex items-center justify-center text-xl sm:text-2xl font-black text-[#D4FF44] shadow-lg shadow-[#D4FF44]/10 shrink-0">
            {formData.name.split(' ').map(n => n[0]).join('').toUpperCase() || 'MK'}
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[9px] font-black uppercase tracking-[0.2em] bg-[#D4FF44] text-black px-2 py-0.5 rounded">
                MK ATHLETE
              </span>
              <span className="text-xs font-bold text-[#888] uppercase tracking-wider">{formData.experience}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">{formData.name}</h1>
            <p className="text-xs text-[#666] mt-1 uppercase tracking-[0.2em] font-medium">
              Goal: <span className="text-[#D4FF44] font-bold">{formData.goal}</span> • Schedule: {formData.trainingDaysPerWeek} days/wk
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsEditing(!isEditing)}
          className="flex items-center justify-center gap-2 bg-[#0A0A0B] hover:bg-[#222] border border-[#222] text-white font-black text-xs px-5 py-3 rounded-2xl transition-all self-start md:self-auto uppercase tracking-wider cursor-pointer"
        >
          <Edit2 className="w-4 h-4 text-[#D4FF44]" />
          <span>{isEditing ? 'CANCEL EDIT' : 'EDIT PROFILE'}</span>
        </button>
      </div>

      {/* EDIT FORM or PROFILE STATS */}
      {isEditing ? (
        <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl p-6 sm:p-8 space-y-6">
          <h2 className="text-xs font-black text-[#888] uppercase tracking-[0.2em]">Update Personal Baseline</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Full Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-4 py-2.5 text-white font-bold text-xs focus:border-[#D4FF44] outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Age</label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-4 py-2.5 text-white font-bold text-xs focus:border-[#D4FF44] outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Weight (kg)</label>
              <input
                type="number"
                step="0.1"
                value={formData.weightKg}
                onChange={(e) => setFormData({ ...formData, weightKg: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-4 py-2.5 text-white font-bold text-xs focus:border-[#D4FF44] outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Height (cm)</label>
              <input
                type="number"
                value={formData.heightCm}
                onChange={(e) => setFormData({ ...formData, heightCm: parseInt(e.target.value) || 0 })}
                className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-4 py-2.5 text-white font-bold text-xs focus:border-[#D4FF44] outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Training Days / Week</label>
              <input
                type="number"
                value={formData.trainingDaysPerWeek}
                onChange={(e) => setFormData({ ...formData, trainingDaysPerWeek: parseInt(e.target.value) || 0 })}
                className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-4 py-2.5 text-white font-bold text-xs focus:border-[#D4FF44] outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] block mb-1">Preferred Duration (mins)</label>
              <input
                type="number"
                value={formData.preferredDurationMin}
                onChange={(e) => setFormData({ ...formData, preferredDurationMin: parseInt(e.target.value) || 0 })}
                className="w-full bg-[#0A0A0B] border border-[#222] rounded-xl px-4 py-2.5 text-white font-bold text-xs focus:border-[#D4FF44] outline-none"
              />
            </div>
          </div>

          <button
            onClick={handleSave}
            className="w-full bg-[#D4FF44] hover:bg-[#c2f033] text-black font-black text-xs uppercase tracking-widest py-4 rounded-2xl transition-colors shadow-xl cursor-pointer"
          >
            SAVE UPDATES
          </button>
        </div>
      ) : (
        /* LIFETIME OVERVIEW STATS */
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-2xl">
            <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Total Workouts</div>
            <div className="text-2xl font-black text-white">{logs.length + 28} <span className="text-xs text-[#666] uppercase font-bold">Sessions</span></div>
          </div>
          <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-2xl">
            <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Lifetime Volume</div>
            <div className="text-2xl font-black text-[#D4FF44]">{totalVolume.toLocaleString()} <span className="text-xs text-[#888] uppercase font-bold">kg</span></div>
          </div>
          <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-2xl">
            <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Longest Streak</div>
            <div className="text-2xl font-black text-white">{formData.streakDays || 12} <span className="text-xs text-[#666] uppercase font-bold">Days</span></div>
          </div>
          <div className="bg-[#161618] border border-[#1F1F22] p-5 rounded-2xl">
            <div className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] mb-1">Active Equipment</div>
            <div className="text-lg font-black text-white line-clamp-1">{formData.equipment}</div>
          </div>
        </div>
      )}

      {/* PERSONAL RECORDS LIST */}
      <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl p-6">
        <h3 className="text-xs font-black text-[#888] uppercase tracking-[0.2em] mb-4">Personal Benchmarks</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {prs.map((pr, i) => (
            <div key={i} className="p-4 bg-[#0A0A0B] rounded-2xl border border-[#222] flex items-center justify-between">
              <span className="font-black text-xs text-white uppercase">{pr.exerciseName}</span>
              <span className="font-black text-sm text-[#D4FF44]">{pr.weightKg > 0 ? `${pr.weightKg} kg` : `${pr.reps} reps`}</span>
            </div>
          ))}
        </div>
      </div>

      {/* DANGER ZONE - RESET DATA */}
      <div className="p-6 bg-[#161618] border border-[#1F1F22] rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h4 className="font-black text-xs text-white uppercase tracking-wider">Reset Application Baseline</h4>
          <p className="text-[10px] text-[#666] uppercase tracking-wider mt-0.5 font-bold">Clears local storage and re-runs onboarding protocol.</p>
        </div>
        <button
          onClick={onResetData}
          className="flex items-center gap-2 bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-900/50 text-xs font-black uppercase tracking-wider px-4 py-2.5 rounded-xl transition-all shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>RESET ALL DATA</span>
        </button>
      </div>

    </div>
  );
};
