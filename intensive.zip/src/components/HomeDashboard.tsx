import React from 'react';
import { Play, Flame, Trophy, Scale, Flame as CalorieIcon, Dumbbell, ArrowUpRight, CalendarCheck, Sparkles, Target } from 'lucide-react';
import { UserProfile, Workout, TrainingProgram, CompletedWorkoutLog } from '../types/fitness';

interface HomeDashboardProps {
  userProfile: UserProfile;
  todayWorkout: Workout;
  currentProgram?: TrainingProgram;
  workoutLogs: CompletedWorkoutLog[];
  onStartWorkout: (workout: Workout) => void;
  onNavigateTab: (tab: any) => void;
  onOpenAICoach: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  userProfile,
  todayWorkout,
  currentProgram,
  workoutLogs,
  onStartWorkout,
  onNavigateTab,
  onOpenAICoach,
}) => {
  // Calculate today's date ISO
  const todayStr = new Date().toISOString().split('T')[0];
  const isTodayCompleted = workoutLogs.some(l => l.dateISO.startsWith(todayStr));

  // Total weekly volume (kg) calculation from logs in the last 7 days
  const sevenDaysAgo = new Date(Date.now() - 86400000 * 7);
  const weeklyLogs = workoutLogs.filter(l => new Date(l.dateISO) >= sevenDaysAgo);
  const totalWeeklyVolume = weeklyLogs.reduce((acc, l) => acc + (l.totalVolumeKg || 0), 0) || 14250;

  // Weekly days status (Mon to Sun mock/real matching)
  const daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const todayDayIndex = (new Date().getDay() + 6) % 7; // 0 for Mon, 6 for Sun

  const weeklySchedule = daysOfWeek.map((day, idx) => {
    if (idx < todayDayIndex) return { day, status: 'completed' };
    if (idx === todayDayIndex) return { day, status: isTodayCompleted ? 'completed' : 'today' };
    if (idx === 6) return { day, status: 'rest' };
    return { day, status: 'pending' };
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Top Greeting & Active Header */}
      <header className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 text-xs font-mono font-bold text-[#D4FF44] tracking-widest uppercase mb-1">
            <span>DAY 01 / 84</span>
            <span>•</span>
            <span>INTENSIVE PROGRAM</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white uppercase italic tracking-tight font-display">
            GOOD {new Date().getHours() < 12 ? 'MORNING' : (new Date().getHours() < 18 ? 'AFTERNOON' : 'EVENING')}, {userProfile.name.split(' ')[0]}.
          </h1>
          <p className="text-[#888] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-bold">
            Personalized training. Structured progression. Real results.
          </p>
        </div>

        <div className="flex space-x-8 text-right shrink-0">
          <div>
            <div className="text-[#888] text-[10px] uppercase tracking-widest mb-1 font-bold">Streak</div>
            <div className="text-xl font-black text-white">{userProfile.streakDays || 1} Days</div>
          </div>
          <div>
            <div className="text-[#888] text-[10px] uppercase tracking-widest mb-1 font-bold">Training Vol.</div>
            <div className="text-xl font-black text-[#D4FF44]">{(totalWeeklyVolume / 1000).toFixed(1)}k kg</div>
          </div>
        </div>
      </header>

      {/* HERO SECTION: TODAY'S WORKOUT */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#161618] to-[#0D0D0E] border border-[#1F1F22] rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col justify-between">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#D4FF44] opacity-5 blur-[100px] pointer-events-none" />
        
        <div className="relative z-10">
          <div className="flex items-center justify-between gap-2 mb-4">
            <span className="bg-[#D4FF44] text-black text-[10px] font-black uppercase px-2.5 py-1 rounded-md tracking-wider">
              TODAY'S WORKOUT
            </span>
            {isTodayCompleted && (
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold uppercase px-2.5 py-0.5 rounded flex items-center gap-1">
                <CalendarCheck className="w-3.5 h-3.5" /> COMPLETED TODAY
              </span>
            )}
          </div>

          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tighter uppercase leading-none mb-3 font-display">
            {todayWorkout.title}
          </h2>

          <p className="text-[#888] text-sm max-w-2xl leading-relaxed mb-6 font-medium">
            {todayWorkout.description}
          </p>

          <div className="flex flex-wrap items-center gap-6 text-xs font-bold text-white mb-8 border-t border-[#222] pt-6">
            <div className="border-r border-[#333] pr-6">
              <div className="text-[#666] text-[10px] uppercase tracking-wider font-bold">Exercises</div>
              <div className="text-xl font-black text-white">{todayWorkout.exercises.length} Exercises</div>
            </div>
            <div className="border-r border-[#333] pr-6">
              <div className="text-[#666] text-[10px] uppercase tracking-wider font-bold">Duration</div>
              <div className="text-xl font-black text-white">{todayWorkout.durationMinutes} Minutes</div>
            </div>
            <div>
              <div className="text-[#666] text-[10px] uppercase tracking-wider font-bold">Intensity</div>
              <div className="text-xl font-black text-[#D4FF44]">HIGH ({todayWorkout.difficulty.toUpperCase()})</div>
            </div>
          </div>

          {/* START WORKOUT CTA */}
          <button
            onClick={() => onStartWorkout(todayWorkout)}
            className="w-full bg-[#D4FF44] hover:bg-[#c3f033] text-black py-4 sm:py-5 rounded-2xl font-black text-base uppercase tracking-widest transition-all shadow-xl shadow-[#D4FF44]/10 group flex items-center justify-center gap-3 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-black" />
            <span>{isTodayCompleted ? "REPEAT TODAY'S WORKOUT" : "START WORKOUT"}</span>
          </button>
        </div>
      </div>

      {/* METRICS & WEEKLY PROGRESS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* WEEKLY SCHEDULE */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F22] rounded-3xl p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#666] font-bold">Weekly Progress</h3>
            <button onClick={() => onNavigateTab('progress')} className="text-[10px] font-bold text-[#D4FF44] uppercase tracking-widest hover:underline cursor-pointer">
              Analytics →
            </button>
          </div>

          <div className="flex justify-between items-center my-4 px-2">
            {weeklySchedule.map((item, idx) => (
              <div key={idx} className="flex flex-col items-center">
                <div className="text-[10px] mb-2 font-bold text-[#666] uppercase">{item.day}</div>
                {item.status === 'completed' ? (
                  <div className="w-9 h-9 rounded-full bg-[#D4FF44] flex items-center justify-center text-black text-xs font-bold shadow-md shadow-[#D4FF44]/10">
                    ✓
                  </div>
                ) : item.status === 'today' ? (
                  <div className="w-9 h-9 rounded-full border-2 border-[#D4FF44] flex items-center justify-center text-white text-xs font-extrabold bg-[#161618]">
                    ○
                  </div>
                ) : item.status === 'rest' ? (
                  <div className="w-9 h-9 rounded-full border border-[#333] flex items-center justify-center text-[#444] text-[10px] font-bold">
                    R
                  </div>
                ) : (
                  <div className="w-9 h-9 rounded-full border border-[#333] flex items-center justify-center text-[#444] text-[10px] font-bold">
                    ○
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-[#222] flex items-center justify-between text-[11px] text-[#666]">
            <span>Active Program: <strong className="text-white uppercase">{currentProgram?.title || '6-Week Muscle Builder'}</strong></span>
            <span className="text-[#D4FF44] font-bold">Wk 3</span>
          </div>
        </div>

        {/* NUTRITION & TARGET SNAPSHOT */}
        <div className="lg:col-span-6 bg-[#161618] border border-[#1F1F22] rounded-3xl p-6 flex flex-col justify-between">
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-[#666] font-bold mb-4">Daily Targets Snapshot</h3>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-[11px] mb-1 font-bold">
                <span className="text-[#888] uppercase tracking-wider">Energy</span>
                <span className="text-white">2,450 / 2,800 kcal</span>
              </div>
              <div className="w-full h-1.5 bg-[#222] rounded-full overflow-hidden">
                <div className="h-full bg-white w-[88%]" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1 font-bold">
                <span className="text-[#888] uppercase tracking-wider">Protein</span>
                <span className="text-[#D4FF44]">155 / 170 g</span>
              </div>
              <div className="w-full h-1.5 bg-[#222] rounded-full overflow-hidden">
                <div className="h-full bg-[#D4FF44] w-[91%]" />
              </div>
            </div>

            <div className="pt-2 grid grid-cols-2 gap-4">
              <div className="bg-[#0A0A0B] p-3 rounded-2xl border border-[#222]">
                <div className="text-[9px] text-[#666] uppercase font-bold tracking-wider">Water Intake</div>
                <div className="text-sm font-black text-white mt-0.5">2.8 / 3.0 L</div>
              </div>
              <div className="bg-[#0A0A0B] p-3 rounded-2xl border border-[#222]">
                <div className="text-[9px] text-[#666] uppercase font-bold tracking-wider">Current Weight</div>
                <div className="text-sm font-black text-white mt-0.5">{userProfile.weightKg} kg</div>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* INTENSIVE HEAD COACH CARD */}
      <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden shadow-2xl">
        <div className="flex items-center gap-5 relative z-10">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#0A0A0B] border-2 border-[#D4FF44] flex items-center justify-center font-black text-[#D4FF44] text-xl sm:text-2xl shrink-0 shadow-lg shadow-[#D4FF44]/10">
            SA
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-[#D4FF44] text-black text-[9px] font-black uppercase px-2 py-0.5 rounded tracking-wider">
                HEAD COACH
              </span>
              <span className="text-xs text-[#888] font-bold uppercase tracking-wider">BODYBUILDING & HYPERTROPHY</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">SR ABHISHEK</h2>
            <p className="text-[#888] text-xs sm:text-sm mt-1 max-w-xl leading-relaxed font-medium">
              "Hypertrophy is not accidental. It is the result of mechanical tension, precise exercise selection, and ruthless progressive overload."
            </p>
          </div>
        </div>

        <button
          onClick={onOpenAICoach}
          className="w-full md:w-auto bg-[#0A0A0B] hover:bg-[#222] border border-[#222] text-[#D4FF44] hover:text-white font-black text-xs px-6 py-4 rounded-2xl uppercase tracking-widest transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-[#D4FF44]" />
          <span>CONSULT COACH SR ABHISHEK</span>
        </button>
      </div>

      {/* FOOTER FEATURE CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div
          onClick={onOpenAICoach}
          className="bg-[#161618] border border-[#1F1F22] hover:border-[#D4FF44]/50 p-6 rounded-2xl flex items-center justify-between cursor-pointer transition-all group"
        >
          <div>
            <div className="text-[10px] text-[#666] font-bold tracking-widest mb-1 uppercase">AI Coach Strategy</div>
            <div className="text-sm font-black text-white uppercase group-hover:text-[#D4FF44] transition-colors">Optimize Rest & Overload</div>
          </div>
          <Sparkles className="w-5 h-5 text-[#D4FF44] shrink-0" />
        </div>

        <div
          onClick={() => onNavigateTab('progress')}
          className="bg-[#161618] border border-[#1F1F22] hover:border-[#D4FF44]/50 p-6 rounded-2xl flex items-center justify-between cursor-pointer transition-all group"
        >
          <div>
            <div className="text-[10px] text-[#666] font-bold tracking-widest mb-1 uppercase">Latest PR Milestone</div>
            <div className="text-sm font-black text-white uppercase group-hover:text-[#D4FF44] transition-colors">Bench Press: 110 kg</div>
          </div>
          <Trophy className="w-5 h-5 text-[#D4FF44] shrink-0" />
        </div>

        <div
          onClick={() => onNavigateTab('programs')}
          className="bg-[#161618] border border-[#1F1F22] hover:border-[#D4FF44]/50 p-6 rounded-2xl flex items-center justify-between cursor-pointer transition-all group"
        >
          <div>
            <div className="text-[10px] text-[#666] font-bold tracking-widest mb-1 uppercase">Program Goal</div>
            <div className="text-sm font-black text-white uppercase group-hover:text-[#D4FF44] transition-colors">{userProfile.goal}</div>
          </div>
          <Target className="w-5 h-5 text-[#D4FF44] shrink-0" />
        </div>
      </div>

    </div>
  );
};
