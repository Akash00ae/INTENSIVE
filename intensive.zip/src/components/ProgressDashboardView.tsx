import React from 'react';
import { Trophy, Dumbbell, Scale } from 'lucide-react';
import { storage } from '../services/storage';

export const ProgressDashboardView: React.FC = () => {
  const prs = storage.getPRs();
  const logs = storage.getWorkoutLogs();
  const measurements = storage.getBodyMeasurements();

  // Mock SVG chart helper for Body Weight
  const weightData = measurements.map((m) => ({ label: m.weekLabel || 'Wk', weight: m.weightKg }));

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Title */}
      <div className="border-b border-[#1F1F22] pb-6">
        <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">Progress & Analytics</h1>
        <p className="text-[#666] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-medium">
          Quantifiable overload metrics, body composition trends, and milestone logs.
        </p>
      </div>

      {/* PERSONAL RECORDS SHOWCASE GRID */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs font-black text-[#888] flex items-center gap-2 uppercase tracking-[0.2em]">
            <Trophy className="w-4 h-4 text-[#D4FF44]" />
            <span>PERSONAL RECORDS</span>
          </h2>
          <span className="text-[10px] text-[#D4FF44] font-black uppercase tracking-widest">LIFETIME PRs</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {prs.map((pr, idx) => {
            const improvementPct = pr.previousRecordKg
              ? Math.round(((pr.weightKg - pr.previousRecordKg) / pr.previousRecordKg) * 100)
              : 8;

            return (
              <div
                key={idx}
                className="bg-[#161618] border border-[#1F1F22] p-5 rounded-2xl transition-all shadow-xl"
              >
                <div className="flex items-center justify-between text-xs text-[#888] font-bold uppercase tracking-wider mb-2">
                  <span>{pr.exerciseName}</span>
                  <span className="px-2 py-0.5 bg-[#D4FF44]/10 text-[#D4FF44] font-black text-[10px] rounded border border-[#D4FF44]/20">
                    +{improvementPct}%
                  </span>
                </div>

                <div className="text-3xl font-black text-white tracking-tight uppercase">
                  {pr.weightKg > 0 ? (
                    <>
                      {pr.weightKg} <span className="text-sm font-bold text-[#666]">kg</span>
                    </>
                  ) : (
                    <>
                      {pr.reps} <span className="text-sm font-bold text-[#666]">reps</span>
                    </>
                  )}
                </div>

                <div className="text-[10px] text-[#666] mt-2 font-bold uppercase tracking-wider flex items-center justify-between">
                  <span>{pr.reps} REPS TARGET</span>
                  <span>{pr.dateISO ? new Date(pr.dateISO).toLocaleDateString() : 'Recent'}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* CHARTS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Body Weight Trend Chart */}
        <div className="bg-[#161618] border border-[#1F1F22] p-6 rounded-3xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-black text-white text-sm uppercase tracking-wider">Body Weight Trend (kg)</h3>
              <p className="text-[10px] text-[#666] uppercase font-bold tracking-widest">Consistent fat loss curve</p>
            </div>
            <Scale className="w-5 h-5 text-[#D4FF44]" />
          </div>

          <div className="h-48 flex items-end justify-between gap-3 pt-8 pb-2 px-4 bg-[#0A0A0B] rounded-2xl border border-[#222]">
            {weightData.map((d, i) => {
              const maxW = 85;
              const minW = 70;
              const heightPct = Math.max(15, Math.min(100, ((d.weight - minW) / (maxW - minW)) * 100));
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                  <span className="text-[10px] font-bold text-[#D4FF44] opacity-0 group-hover:opacity-100 transition-opacity">
                    {d.weight}kg
                  </span>
                  <div className="w-full max-w-[28px] bg-[#D4FF44] rounded-t-md transition-all" style={{ height: `${heightPct}%` }} />
                  <span className="text-[10px] font-bold text-[#666] uppercase">{d.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weekly Training Volume Chart */}
        <div className="bg-[#161618] border border-[#1F1F22] p-6 rounded-3xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-black text-white text-sm uppercase tracking-wider">Training Volume Overload (kg)</h3>
              <p className="text-[10px] text-[#666] uppercase font-bold tracking-widest">Cumulative load lifted</p>
            </div>
            <Dumbbell className="w-5 h-5 text-[#D4FF44]" />
          </div>

          <div className="h-48 flex items-end justify-between gap-3 pt-8 pb-2 px-4 bg-[#0A0A0B] rounded-2xl border border-[#222]">
            {[
              { week: 'Wk 1', vol: 11200 },
              { week: 'Wk 2', vol: 12400 },
              { week: 'Wk 3', vol: 13100 },
              { week: 'Wk 4', vol: 14250 },
            ].map((v, i) => {
              const heightPct = (v.vol / 16000) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                  <span className="text-[10px] font-bold text-[#D4FF44] opacity-0 group-hover:opacity-100 transition-opacity">
                    {v.vol}kg
                  </span>
                  <div className="w-full max-w-[28px] bg-[#D4FF44] rounded-t-md transition-all" style={{ height: `${heightPct}%` }} />
                  <span className="text-[10px] font-bold text-[#666] uppercase">{v.week}</span>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* RECENT COMPLETED WORKOUT HISTORY TABLE */}
      <div className="bg-[#161618] border border-[#1F1F22] rounded-3xl p-6">
        <h3 className="text-xs font-black text-[#888] uppercase tracking-[0.2em] mb-4">Recent Completed Workouts</h3>
        <div className="space-y-3">
          {logs.slice(0, 5).map((log) => (
            <div
              key={log.id}
              className="p-4 bg-[#0A0A0B] rounded-2xl border border-[#222] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div>
                <div className="font-black text-xs text-white uppercase">{log.workoutTitle}</div>
                <div className="text-[10px] text-[#666] uppercase font-bold mt-0.5">
                  {log.totalExercisesCount} EXERCISES • {Math.round(log.durationSeconds / 60)} MINS • {log.dateFormatted}
                </div>
              </div>

              <div className="text-right">
                <div className="text-sm font-black text-[#D4FF44]">{log.totalVolumeKg.toLocaleString()} KG</div>
                <div className="text-[10px] text-[#666] font-bold uppercase">{log.totalSetsCompleted} SETS LOGGED</div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
