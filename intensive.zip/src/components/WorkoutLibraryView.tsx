import React, { useState } from 'react';
import { Search, Play, Dumbbell, Target, Layers, Clock } from 'lucide-react';
import { Workout, MuscleGroup } from '../types/fitness';
import { SAMPLE_WORKOUTS } from '../data/initialData';

interface WorkoutLibraryViewProps {
  onStartWorkout: (workout: Workout) => void;
}

export const WorkoutLibraryView: React.FC<WorkoutLibraryViewProps> = ({ onStartWorkout }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGoal, setSelectedGoal] = useState<string>('All');
  const [selectedMuscle, setSelectedMuscle] = useState<string>('All');

  const goals = ['All', 'Build Muscle', 'Fat Loss', 'Increase Strength', 'Improve Fitness', 'Athletic Performance'];
  const muscleGroups = ['All', 'Chest', 'Back', 'Shoulders', 'Arms', 'Legs', 'Glutes', 'Core', 'Full Body'];

  const filteredWorkouts = SAMPLE_WORKOUTS.filter((workout) => {
    const matchesSearch = workout.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      workout.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesGoal = selectedGoal === 'All' || workout.goal === selectedGoal;
    const matchesMuscle = selectedMuscle === 'All' || workout.primaryMuscles.includes(selectedMuscle as MuscleGroup);

    return matchesSearch && matchesGoal && matchesMuscle;
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      
      {/* Title & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#1F1F22] pb-6">
        <div>
          <h1 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">Workout Library</h1>
          <p className="text-[#666] text-xs sm:text-sm mt-1 uppercase tracking-[0.2em] font-medium">
            High-intensity workouts engineered for maximum output.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#666] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search routine or exercise..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#161618] border border-[#1F1F22] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-[#555] focus:outline-none focus:border-[#D4FF44] font-bold uppercase tracking-wider transition-all"
          />
        </div>
      </div>

      {/* Filter Chips Bar */}
      <div className="space-y-4 bg-[#161618] p-5 rounded-2xl border border-[#1F1F22]">
        
        {/* Goal Filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] shrink-0 mr-2 flex items-center gap-1">
            <Target className="w-3.5 h-3.5 text-[#D4FF44]" /> Goal:
          </span>
          {goals.map((goal) => (
            <button
              key={goal}
              onClick={() => setSelectedGoal(goal)}
              className={`px-3 py-1.5 rounded-lg text-[11px] font-bold uppercase tracking-wider whitespace-nowrap transition-all cursor-pointer ${
                selectedGoal === goal
                  ? 'bg-[#D4FF44] text-black shadow-md shadow-[#D4FF44]/10'
                  : 'bg-[#0A0A0B] text-[#888] hover:text-white border border-[#222]'
              }`}
            >
              {goal}
            </button>
          ))}
        </div>

        {/* Muscle Filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[10px] font-bold text-[#666] uppercase tracking-[0.2em] shrink-0 mr-2 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-[#D4FF44]" /> Muscle:
          </span>
          {muscleGroups.map((muscle) => (
            <button
              key={muscle}
              onClick={() => setSelectedMuscle(muscle)}
              className={`px-3 py-1.5 rounded-lg text-[11px] font-bold uppercase tracking-wider whitespace-nowrap transition-all cursor-pointer ${
                selectedMuscle === muscle
                  ? 'bg-[#D4FF44] text-black shadow-md shadow-[#D4FF44]/10'
                  : 'bg-[#0A0A0B] text-[#888] hover:text-white border border-[#222]'
              }`}
            >
              {muscle}
            </button>
          ))}
        </div>

      </div>

      {/* WORKOUT CARDS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredWorkouts.map((workout) => (
          <div
            key={workout.id}
            className="bg-[#161618] border border-[#1F1F22] hover:border-[#D4FF44]/50 rounded-3xl p-6 flex flex-col justify-between transition-all group"
          >
            <div>
              {/* Card Header Tags */}
              <div className="flex items-center justify-between gap-2 mb-4">
                <span className="px-2.5 py-1 bg-[#D4FF44]/10 text-[#D4FF44] border border-[#D4FF44]/20 font-black text-[10px] uppercase tracking-wider rounded-md">
                  {workout.goal}
                </span>
                <span className="text-[10px] font-bold text-[#888] bg-[#0A0A0B] border border-[#222] px-2.5 py-1 rounded-md uppercase tracking-wider">
                  {workout.difficulty}
                </span>
              </div>

              {/* Title & Description */}
              <h3 className="text-xl font-black text-white uppercase tracking-tight group-hover:text-[#D4FF44] transition-colors mb-2">
                {workout.title}
              </h3>
              <p className="text-xs text-[#888] leading-relaxed mb-6 font-medium line-clamp-2">
                {workout.description}
              </p>

              {/* Exercise List Summary */}
              <div className="space-y-2 mb-6 bg-[#0A0A0B] p-4 rounded-2xl border border-[#222]">
                <div className="text-[9px] font-bold text-[#666] uppercase tracking-[0.2em] mb-2">Target Exercises</div>
                {workout.exercises.slice(0, 3).map((ex, idx) => (
                  <div key={idx} className="text-xs text-[#EAEAEA] font-bold flex items-center justify-between uppercase">
                    <span>• {ex.exerciseName}</span>
                    <span className="text-[#666] text-[10px]">{ex.sets.length} SETS</span>
                  </div>
                ))}
                {workout.exercises.length > 3 && (
                  <div className="text-[10px] text-[#D4FF44] font-bold pt-1 uppercase tracking-wider">
                    + {workout.exercises.length - 3} MORE EXERCISES
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Card Footer */}
            <div>
              <div className="flex items-center justify-between text-xs text-[#888] font-bold mb-4 pt-4 border-t border-[#222]">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#666]" />
                  <span>{workout.durationMinutes} MINS</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Dumbbell className="w-3.5 h-3.5 text-[#666]" />
                  <span>{workout.exercises.length} EXERCISES</span>
                </div>
              </div>

              <button
                onClick={() => onStartWorkout(workout)}
                className="w-full flex items-center justify-center gap-2 bg-white hover:bg-[#D4FF44] text-black font-black text-xs py-3.5 rounded-xl uppercase tracking-widest transition-colors cursor-pointer shadow-lg"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                <span>START WORKOUT</span>
              </button>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
