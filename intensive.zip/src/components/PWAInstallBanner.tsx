import React, { useState, useEffect } from 'react';
import { Download, Smartphone, X, Check, Share, Sparkles } from 'lucide-react';

export const PWAInstallBanner: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [showBanner, setShowBanner] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);
  const [installedSuccessfully, setInstalledSuccessfully] = useState(false);

  useEffect(() => {
    // Check if running in standalone mode (installed app)
    const isStandaloneMode =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes('android-app://');

    setIsStandalone(isStandaloneMode);

    // Detect iOS
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    // Don't show if already in standalone mode or dismissed recently
    const dismissed = localStorage.getItem('intensive_pwa_banner_dismissed');
    if (isStandaloneMode || dismissed) {
      return;
    }

    // Listen for Android / Chrome beforeinstallprompt event
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowBanner(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Listen for app installed event
    const handleAppInstalled = () => {
      setInstalledSuccessfully(true);
      setShowBanner(false);
      setDeferredPrompt(null);
      setTimeout(() => setInstalledSuccessfully(false), 5000);
    };

    window.addEventListener('appinstalled', handleAppInstalled);

    // For iOS or browsers where event hasn't fired yet, show banner after brief delay
    const timer = setTimeout(() => {
      if (!isStandaloneMode && !dismissed) {
        setShowBanner(true);
      }
    }, 2500);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      clearTimeout(timer);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        console.log('[PWA] User accepted the install prompt');
        setInstalledSuccessfully(true);
      }
      setDeferredPrompt(null);
      setShowBanner(false);
    } else if (isIOS) {
      setShowIOSInstructions(true);
    } else {
      // Fallback instructions
      alert('To install INTENSIVE: Tap your browser menu (⋮ or share) and select "Add to Home Screen" or "Install App".');
    }
  };

  const handleDismiss = () => {
    setShowBanner(false);
    localStorage.setItem('intensive_pwa_banner_dismissed', 'true');
  };

  if (isStandalone || (!showBanner && !installedSuccessfully)) {
    return null;
  }

  return (
    <>
      {/* SUCCESS TOAST */}
      {installedSuccessfully && (
        <div className="bg-[#D4FF44] text-black px-4 py-3 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-between shadow-2xl mb-6 animate-fade-in border border-black/20">
          <div className="flex items-center gap-2">
            <Check className="w-5 h-5 stroke-[3]" />
            <span>INTENSIVE App Installed Successfully! Launch from your home screen.</span>
          </div>
        </div>
      )}

      {/* INSTALL APP PROMPT BANNER */}
      {showBanner && (
        <div className="bg-gradient-to-r from-[#161618] via-[#1A1A1E] to-[#161618] border border-[#D4FF44]/30 rounded-3xl p-4 sm:p-5 mb-6 relative shadow-2xl overflow-hidden group">
          {/* Neon Glow Accent */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4FF44]/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-[#0A0A0B] border border-[#D4FF44]/40 flex items-center justify-center shrink-0 shadow-lg shadow-[#D4FF44]/10">
                <img src="/icon.svg" alt="INTENSIVE App Icon" className="w-8 h-8" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-white font-black text-sm uppercase tracking-tight">INSTALL INTENSIVE</span>
                  <span className="bg-[#D4FF44]/15 border border-[#D4FF44]/30 text-[#D4FF44] text-[9px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5" /> PWA NATIVE
                  </span>
                </div>
                <p className="text-[#888] text-xs mt-0.5 font-medium">
                  Add to Home Screen for fullscreen training, offline workouts, and instant load speed.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                onClick={handleDismiss}
                className="p-2.5 text-[#666] hover:text-white rounded-xl hover:bg-[#222] transition-colors cursor-pointer"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>

              <button
                onClick={handleInstallClick}
                className="flex-1 sm:flex-none bg-[#D4FF44] hover:bg-[#b8e625] text-black font-black text-xs px-5 py-3 rounded-xl uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#D4FF44]/20 cursor-pointer active:scale-95"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>INSTALL APP</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* iOS INSTALL INSTRUCTIONS MODAL */}
      {showIOSInstructions && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#161618] border border-[#222] rounded-3xl max-w-sm w-full p-6 text-center space-y-5 shadow-2xl relative">
            <button
              onClick={() => setShowIOSInstructions(false)}
              className="absolute top-4 right-4 text-[#888] hover:text-white p-2 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 rounded-2xl bg-[#0A0A0B] border border-[#D4FF44] mx-auto flex items-center justify-center p-2 shadow-xl">
              <img src="/icon.svg" alt="INTENSIVE" className="w-10 h-10" />
            </div>

            <div>
              <h3 className="text-xl font-black text-white uppercase tracking-tight">Install INTENSIVE on iOS</h3>
              <p className="text-[#888] text-xs mt-1 leading-relaxed">
                Install as a native home screen app for full screen view and offline logging.
              </p>
            </div>

            <div className="bg-[#0A0A0B] border border-[#222] p-4 rounded-2xl text-left space-y-3 text-xs text-zinc-300">
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-[#222] text-[#D4FF44] font-black flex items-center justify-center shrink-0">1</span>
                <span>Tap the <Share className="w-4 h-4 inline text-[#D4FF44]" /> <strong>Share button</strong> in Safari menu bar.</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-[#222] text-[#D4FF44] font-black flex items-center justify-center shrink-0">2</span>
                <span>Scroll down and select <strong>"Add to Home Screen"</strong>.</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-[#222] text-[#D4FF44] font-black flex items-center justify-center shrink-0">3</span>
                <span>Tap <strong>Add</strong> in top right corner to launch.</span>
              </div>
            </div>

            <button
              onClick={() => setShowIOSInstructions(false)}
              className="w-full bg-[#D4FF44] text-black font-black text-xs py-3 rounded-xl uppercase tracking-widest cursor-pointer"
            >
              GOT IT
            </button>
          </div>
        </div>
      )}
    </>
  );
};
