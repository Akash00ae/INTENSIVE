import {
  UserProfile,
  Workout,
  TrainingProgram,
  FoodItem,
  PersonalRecord,
  Challenge,
  BodyMeasurementLog,
  CompletedWorkoutLog
} from '../types/fitness';

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: 'Akash',
  age: 21,
  gender: 'Male',
  heightCm: 170,
  heightUnit: 'cm',
  weightKg: 72,
  weightUnit: 'kg',
  targetWeightKg: 78,
  optionalMeasurements: {
    waistCm: 81,
    chestCm: 102,
    armsCm: 37,
    thighsCm: 58
  },
  trainingDurationExperience: '1–2 years',
  experience: 'Intermediate',
  goal: 'Build Muscle',
  secondaryGoals: ['Build Strength'],
  physiquePriorities: ['Chest', 'Arms', 'Shoulders'],
  trainingDaysPerWeek: 5,
  preferredDurationMin: 60,
  location: 'Full Gym',
  availableEquipmentList: ['Barbell', 'Dumbbells', 'Bench', 'Squat Rack', 'Cable Machine', 'Machines'],
  equipment: 'Full Gym',
  preferredTrainingTypes: ['Bodybuilding', 'Strength Training'],
  perceivedIntensity: 'Very Intense',
  outsideActivity: 'Moderately active',
  dailySteps: '8,000–10,000',
  sleepDuration: '7–8 hours',
  workLifeActivity: 'Mixed',
  preferredSplit: 'Push / Pull / Legs',
  estimatedDailyCalories: 2650,
  estimatedDailyProteinG: 160,
  currentProgramId: 'prog-6wk-muscle',
  isOnboarded: false, // Default to false so new users get the multi-step onboarding experience!
  streakDays: 1,
  lastWorkoutDate: new Date().toISOString().split('T')[0],
};

export const SAMPLE_WORKOUTS: Workout[] = [
  {
    id: 'w-chest-triceps',
    title: 'Chest + Triceps Hypertrophy',
    goal: 'Build Muscle',
    primaryMuscles: ['Chest', 'Arms'],
    durationMinutes: 52,
    difficulty: 'Intermediate',
    description: 'High-intensity push protocol targeting upper & middle chest with isolation for triceps.',
    exercises: [
      {
        exerciseId: 'ex-incline-db-press',
        exerciseName: 'Incline Dumbbell Press',
        targetMuscle: 'Chest',
        restSeconds: 90,
        sets: [
          { setNumber: 1, targetReps: 10, targetWeightKg: 24, completedReps: 10, completedWeightKg: 24, isCompleted: true },
          { setNumber: 2, targetReps: 10, targetWeightKg: 26, completedReps: 10, completedWeightKg: 26, isCompleted: true },
          { setNumber: 3, targetReps: 8, targetWeightKg: 28 },
          { setNumber: 4, targetReps: 8, targetWeightKg: 28 },
        ]
      },
      {
        exerciseId: 'ex-barbell-bench',
        exerciseName: 'Flat Barbell Bench Press',
        targetMuscle: 'Chest',
        restSeconds: 120,
        sets: [
          { setNumber: 1, targetReps: 8, targetWeightKg: 65 },
          { setNumber: 2, targetReps: 8, targetWeightKg: 70 },
          { setNumber: 3, targetReps: 6, targetWeightKg: 72.5 },
        ]
      },
      {
        exerciseId: 'ex-cable-fly',
        exerciseName: 'Cable Chest Flyes',
        targetMuscle: 'Chest',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 15 },
          { setNumber: 2, targetReps: 12, targetWeightKg: 17.5 },
          { setNumber: 3, targetReps: 12, targetWeightKg: 17.5 },
        ]
      },
      {
        exerciseId: 'ex-tricep-pushdown',
        exerciseName: 'Tricep Rope Pushdowns',
        targetMuscle: 'Arms',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 22.5 },
          { setNumber: 2, targetReps: 12, targetWeightKg: 25 },
          { setNumber: 3, targetReps: 10, targetWeightKg: 27.5 },
        ]
      },
      {
        exerciseId: 'ex-overhead-tricep',
        exerciseName: 'Overhead DB Tricep Extension',
        targetMuscle: 'Arms',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 10, targetWeightKg: 20 },
          { setNumber: 2, targetReps: 10, targetWeightKg: 22 },
          { setNumber: 3, targetReps: 10, targetWeightKg: 22 },
        ]
      }
    ]
  },
  {
    id: 'w-back-biceps',
    title: 'Back + Biceps Thickness & Width',
    goal: 'Build Muscle',
    primaryMuscles: ['Back', 'Arms'],
    durationMinutes: 55,
    difficulty: 'Intermediate',
    description: 'Heavy pulls for lat width and upper back thickness combined with biceps overload.',
    exercises: [
      {
        exerciseId: 'ex-lat-pulldown',
        exerciseName: 'Wide Grip Lat Pulldown',
        targetMuscle: 'Back',
        restSeconds: 90,
        sets: [
          { setNumber: 1, targetReps: 10, targetWeightKg: 55 },
          { setNumber: 2, targetReps: 10, targetWeightKg: 60 },
          { setNumber: 3, targetReps: 8, targetWeightKg: 65 },
        ]
      },
      {
        exerciseId: 'ex-bent-over-row',
        exerciseName: 'Barbell Bent-Over Row',
        targetMuscle: 'Back',
        restSeconds: 90,
        sets: [
          { setNumber: 1, targetReps: 8, targetWeightKg: 50 },
          { setNumber: 2, targetReps: 8, targetWeightKg: 60 },
          { setNumber: 3, targetReps: 8, targetWeightKg: 60 },
        ]
      },
      {
        exerciseId: 'ex-seated-cable-row',
        exerciseName: 'Seated Cable Row (Close Grip)',
        targetMuscle: 'Back',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 50 },
          { setNumber: 2, targetReps: 10, targetWeightKg: 55 },
          { setNumber: 3, targetReps: 10, targetWeightKg: 60 },
        ]
      },
      {
        exerciseId: 'ex-ez-bar-curl',
        exerciseName: 'EZ-Bar Bicep Curl',
        targetMuscle: 'Arms',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 10, targetWeightKg: 25 },
          { setNumber: 2, targetReps: 10, targetWeightKg: 30 },
          { setNumber: 3, targetReps: 8, targetWeightKg: 32.5 },
        ]
      },
      {
        exerciseId: 'ex-hammer-curl',
        exerciseName: 'Dumbbell Hammer Curls',
        targetMuscle: 'Arms',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 14 },
          { setNumber: 2, targetReps: 10, targetWeightKg: 16 },
          { setNumber: 3, targetReps: 10, targetWeightKg: 16 },
        ]
      }
    ]
  },
  {
    id: 'w-quads-glutes-calves',
    title: 'Legs: Quads, Glutes & Calves',
    goal: 'Build Muscle',
    primaryMuscles: ['Legs', 'Glutes'],
    durationMinutes: 60,
    difficulty: 'Advanced',
    description: 'Complete lower body development featuring heavy squats, leg press, and lunges.',
    exercises: [
      {
        exerciseId: 'ex-barbell-squat',
        exerciseName: 'Barbell Back Squat',
        targetMuscle: 'Legs',
        restSeconds: 120,
        sets: [
          { setNumber: 1, targetReps: 8, targetWeightKg: 80 },
          { setNumber: 2, targetReps: 8, targetWeightKg: 90 },
          { setNumber: 3, targetReps: 6, targetWeightKg: 100 },
          { setNumber: 4, targetReps: 6, targetWeightKg: 100 },
        ]
      },
      {
        exerciseId: 'ex-leg-press',
        exerciseName: '45-Degree Leg Press',
        targetMuscle: 'Legs',
        restSeconds: 90,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 140 },
          { setNumber: 2, targetReps: 10, targetWeightKg: 160 },
          { setNumber: 3, targetReps: 10, targetWeightKg: 180 },
        ]
      },
      {
        exerciseId: 'ex-walking-lunge',
        exerciseName: 'Dumbbell Walking Lunges',
        targetMuscle: 'Glutes',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 16 },
          { setNumber: 2, targetReps: 12, targetWeightKg: 18 },
          { setNumber: 3, targetReps: 12, targetWeightKg: 18 },
        ]
      },
      {
        exerciseId: 'ex-calf-raise',
        exerciseName: 'Standing Calf Raises',
        targetMuscle: 'Legs',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 15, targetWeightKg: 60 },
          { setNumber: 2, targetReps: 15, targetWeightKg: 70 },
          { setNumber: 3, targetReps: 15, targetWeightKg: 70 },
        ]
      }
    ]
  },
  {
    id: 'w-shoulders-abs',
    title: 'Shoulders & Core Sculpt',
    goal: 'Increase Strength',
    primaryMuscles: ['Shoulders', 'Core'],
    durationMinutes: 45,
    difficulty: 'Intermediate',
    description: 'Overhead press strength work combined with lateral head isolation and rigid core stability.',
    exercises: [
      {
        exerciseId: 'ex-overhead-press',
        exerciseName: 'Standing Overhead Barbell Press',
        targetMuscle: 'Shoulders',
        restSeconds: 120,
        sets: [
          { setNumber: 1, targetReps: 8, targetWeightKg: 40 },
          { setNumber: 2, targetReps: 6, targetWeightKg: 45 },
          { setNumber: 3, targetReps: 6, targetWeightKg: 50 },
        ]
      },
      {
        exerciseId: 'ex-lateral-raise',
        exerciseName: 'Dumbbell Lateral Raises',
        targetMuscle: 'Shoulders',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 10 },
          { setNumber: 2, targetReps: 12, targetWeightKg: 12 },
          { setNumber: 3, targetReps: 15, targetWeightKg: 12 },
        ]
      },
      {
        exerciseId: 'ex-face-pull',
        exerciseName: 'Cable Face Pulls',
        targetMuscle: 'Shoulders',
        restSeconds: 60,
        sets: [
          { setNumber: 1, targetReps: 15, targetWeightKg: 20 },
          { setNumber: 2, targetReps: 15, targetWeightKg: 22.5 },
          { setNumber: 3, targetReps: 15, targetWeightKg: 22.5 },
        ]
      },
      {
        exerciseId: 'ex-hanging-leg-raise',
        exerciseName: 'Hanging Leg Raises',
        targetMuscle: 'Core',
        restSeconds: 45,
        sets: [
          { setNumber: 1, targetReps: 12, targetWeightKg: 0 },
          { setNumber: 2, targetReps: 12, targetWeightKg: 0 },
          { setNumber: 3, targetReps: 12, targetWeightKg: 0 },
        ]
      }
    ]
  },
  {
    id: 'w-hiit-burn',
    title: '30-Min Fat Loss Conditioning',
    goal: 'Fat Loss',
    primaryMuscles: ['Full Body', 'Core'],
    durationMinutes: 30,
    difficulty: 'Beginner',
    description: 'High tempo athletic circuit designed for maximum metabolic rate and cardiovascular endurance.',
    exercises: [
      {
        exerciseId: 'ex-kettlebell-swing',
        exerciseName: 'Kettlebell Swings',
        targetMuscle: 'Full Body',
        restSeconds: 30,
        sets: [
          { setNumber: 1, targetReps: 20, targetWeightKg: 16 },
          { setNumber: 2, targetReps: 20, targetWeightKg: 16 },
          { setNumber: 3, targetReps: 20, targetWeightKg: 20 },
        ]
      },
      {
        exerciseId: 'ex-burpees',
        exerciseName: 'Athletic Burpees',
        targetMuscle: 'Full Body',
        restSeconds: 30,
        sets: [
          { setNumber: 1, targetReps: 15, targetWeightKg: 0 },
          { setNumber: 2, targetReps: 15, targetWeightKg: 0 },
          { setNumber: 3, targetReps: 15, targetWeightKg: 0 },
        ]
      },
      {
        exerciseId: 'ex-mountain-climbers',
        exerciseName: 'Mountain Climbers',
        targetMuscle: 'Core',
        restSeconds: 30,
        sets: [
          { setNumber: 1, targetReps: 30, targetWeightKg: 0 },
          { setNumber: 2, targetReps: 30, targetWeightKg: 0 },
          { setNumber: 3, targetReps: 30, targetWeightKg: 0 },
        ]
      }
    ]
  }
];

export const SAMPLE_PROGRAMS: TrainingProgram[] = [
  {
    id: 'prog-30day-fatloss',
    title: '30-DAY FAT LOSS',
    tagline: 'High-density conditioning & muscle retention protocol.',
    goal: 'Fat Loss',
    durationWeeks: 4,
    daysPerWeek: 5,
    durationMinutes: 45,
    difficulty: 'Intermediate',
    equipment: 'Dumbbells',
    description: 'Designed to maximize caloric burn while preserving lean tissue using high-density supersets and short rest intervals.',
    weeklySchedule: [
      { dayNumber: 1, title: 'Upper Body Density Burn', workoutId: 'w-chest-triceps', isRestDay: false },
      { dayNumber: 2, title: 'Lower Body HIIT & Core', workoutId: 'w-quads-glutes-calves', isRestDay: false },
      { dayNumber: 3, title: 'Active Recovery Walk', isRestDay: true },
      { dayNumber: 4, title: 'Pull & Metabolic Circuit', workoutId: 'w-back-biceps', isRestDay: false },
      { dayNumber: 5, title: 'Full Body HIIT Conditioning', workoutId: 'w-hiit-burn', isRestDay: false },
      { dayNumber: 6, title: 'Shoulders & Core Burn', workoutId: 'w-shoulders-abs', isRestDay: false },
      { dayNumber: 7, title: 'Complete Rest Day', isRestDay: true },
    ]
  },
  {
    id: 'prog-6wk-muscle',
    title: '6-WEEK MUSCLE BUILDER',
    tagline: 'Hypertrophy program focusing on mechanical tension and volume.',
    goal: 'Build Muscle',
    durationWeeks: 6,
    daysPerWeek: 5,
    durationMinutes: 60,
    difficulty: 'Intermediate',
    equipment: 'Full Gym',
    description: 'The flagship INTENSIVE hypertrophy split by Head Coach SR Abhishek. Focuses on progressive overload across major compound movements with strategic isolation.',
    weeklySchedule: [
      { dayNumber: 1, title: 'Push: Chest, Shoulders & Triceps', workoutId: 'w-chest-triceps', isRestDay: false },
      { dayNumber: 2, title: 'Pull: Lats, Rhomboids & Biceps', workoutId: 'w-back-biceps', isRestDay: false },
      { dayNumber: 3, title: 'Active Recovery', isRestDay: true },
      { dayNumber: 4, title: 'Legs: Quads, Hamstrings & Calves', workoutId: 'w-quads-glutes-calves', isRestDay: false },
      { dayNumber: 5, title: 'Upper Body Pump', workoutId: 'w-shoulders-abs', isRestDay: false },
      { dayNumber: 6, title: 'Full Body Functional Overload', workoutId: 'w-hiit-burn', isRestDay: false },
      { dayNumber: 7, title: 'Rest & Nutrient Supercompensation', isRestDay: true },
    ]
  },
  {
    id: 'prog-strength-accelerator',
    title: 'STRENGTH ACCELERATOR',
    tagline: 'Heavy barbell protocol for maximal force output.',
    goal: 'Increase Strength',
    durationWeeks: 8,
    daysPerWeek: 4,
    durationMinutes: 60,
    difficulty: 'Advanced',
    equipment: 'Full Gym',
    description: 'Periodized heavy lift training built around Bench Press, Back Squat, Deadlift, and Standing Overhead Press.',
    weeklySchedule: [
      { dayNumber: 1, title: 'Heavy Bench Press & Upper Push', workoutId: 'w-chest-triceps', isRestDay: false },
      { dayNumber: 2, title: 'Heavy Back Squat & Lower Drive', workoutId: 'w-quads-glutes-calves', isRestDay: false },
      { dayNumber: 3, title: 'Rest', isRestDay: true },
      { dayNumber: 4, title: 'Heavy Deadlift & Lat Pulls', workoutId: 'w-back-biceps', isRestDay: false },
      { dayNumber: 5, title: 'Overhead Press & Delts', workoutId: 'w-shoulders-abs', isRestDay: false },
      { dayNumber: 6, title: 'Rest', isRestDay: true },
      { dayNumber: 7, title: 'Rest', isRestDay: true },
    ]
  },
  {
    id: 'prog-hiit-intensive',
    title: 'HIIT INTENSIVE',
    tagline: '30-minute high intensity interval training for maximum speed.',
    goal: 'Improve Fitness',
    durationWeeks: 4,
    daysPerWeek: 4,
    durationMinutes: 30,
    difficulty: 'Beginner',
    equipment: 'No Equipment',
    description: 'Zero-equipment bodyweight conditioning designed for high stamina, explosive power, and time efficiency.',
    weeklySchedule: [
      { dayNumber: 1, title: 'Bodyweight HIIT Circuit 1', workoutId: 'w-hiit-burn', isRestDay: false },
      { dayNumber: 2, title: 'Core & Mobility Focus', workoutId: 'w-shoulders-abs', isRestDay: false },
      { dayNumber: 3, title: 'Rest', isRestDay: true },
      { dayNumber: 4, title: 'Bodyweight HIIT Circuit 2', workoutId: 'w-hiit-burn', isRestDay: false },
      { dayNumber: 5, title: 'Full Body Endurance Sprint', workoutId: 'w-hiit-burn', isRestDay: false },
      { dayNumber: 6, title: 'Rest', isRestDay: true },
      { dayNumber: 7, title: 'Rest', isRestDay: true },
    ]
  },
  {
    id: 'prog-athletic-conditioning',
    title: 'ATHLETIC CONDITIONING',
    tagline: 'Uncompromising athletic agility, speed, and functional endurance.',
    goal: 'Athletic Performance',
    durationWeeks: 6,
    daysPerWeek: 5,
    durationMinutes: 60,
    difficulty: 'Advanced',
    equipment: 'Full Gym',
    description: 'Pro-level athletic training incorporating plyometrics, compound power lifts, core rotational strength, and mobility.',
    weeklySchedule: [
      { dayNumber: 1, title: 'Explosive Power & Upper Body', workoutId: 'w-chest-triceps', isRestDay: false },
      { dayNumber: 2, title: 'Unilateral Lower & Sprint Work', workoutId: 'w-quads-glutes-calves', isRestDay: false },
      { dayNumber: 3, title: 'Rest & Active Mobility', isRestDay: true },
      { dayNumber: 4, title: 'Posterior Chain Power', workoutId: 'w-back-biceps', isRestDay: false },
      { dayNumber: 5, title: 'Metabolic Athletic Circuit', workoutId: 'w-hiit-burn', isRestDay: false },
      { dayNumber: 6, title: 'Rotational Core & Shoulders', workoutId: 'w-shoulders-abs', isRestDay: false },
      { dayNumber: 7, title: 'Rest Day', isRestDay: true },
    ]
  }
];

export const SAMPLE_FOOD_DATABASE: FoodItem[] = [
  { id: 'f-1', name: 'Eggs (Whole)', category: 'Protein', servingSize: '2 large (100g)', calories: 143, proteinG: 12.6, carbsG: 0.8, fatG: 9.5 },
  { id: 'f-2', name: 'Chicken Breast (Grilled)', category: 'Protein', servingSize: '150g', calories: 247, proteinG: 46.5, carbsG: 0, fatG: 5.4 },
  { id: 'f-3', name: 'Paneer (Cottage Cheese)', category: 'Indian', servingSize: '100g', calories: 265, proteinG: 18.3, carbsG: 3.1, fatG: 20.8 },
  { id: 'f-4', name: 'Dal (Tadka / Moong / Toor)', category: 'Indian', servingSize: '1 bowl (200g cooked)', calories: 180, proteinG: 9.5, carbsG: 28, fatG: 4.2 },
  { id: 'f-5', name: 'Steamed White / Brown Rice', category: 'Indian', servingSize: '1 cup (150g cooked)', calories: 195, proteinG: 4.2, carbsG: 42, fatG: 0.5 },
  { id: 'f-6', name: 'Whole Wheat Roti / Chapati', category: 'Indian', servingSize: '2 medium rotis', calories: 170, proteinG: 5.8, carbsG: 34, fatG: 1.2 },
  { id: 'f-7', name: 'Steamed Idli', category: 'Indian', servingSize: '3 idlis (150g)', calories: 190, proteinG: 6.2, carbsG: 39, fatG: 0.8 },
  { id: 'f-8', name: 'Plain Dosa', category: 'Indian', servingSize: '1 dosa (100g)', calories: 170, proteinG: 4.1, carbsG: 29, fatG: 3.8 },
  { id: 'f-9', name: 'Oats with Milk', category: 'Global', servingSize: '1 bowl (60g oats + milk)', calories: 280, proteinG: 13, carbsG: 44, fatG: 6 },
  { id: 'f-10', name: 'Curd / Greek Yogurt', category: 'Indian', servingSize: '1 cup (200g)', calories: 120, proteinG: 10, carbsG: 8, fatG: 4.5 },
  { id: 'f-11', name: 'Whey Protein Scoop', category: 'Protein', servingSize: '1 scoop (30g)', calories: 120, proteinG: 24, carbsG: 2, fatG: 1.5 },
  { id: 'f-12', name: 'Banana', category: 'Snack', servingSize: '1 medium (118g)', calories: 105, proteinG: 1.3, carbsG: 27, fatG: 0.3 },
  { id: 'f-13', name: 'Almonds / Nuts', category: 'Snack', servingSize: '1 handful (30g)', calories: 170, proteinG: 6, carbsG: 6, fatG: 14 },
  { id: 'f-14', name: 'Mixed Vegetables Curry', category: 'Indian', servingSize: '1 bowl (180g)', calories: 140, proteinG: 3.5, carbsG: 16, fatG: 6.5 },
  { id: 'f-15', name: 'Fish Fillet (Baked)', category: 'Protein', servingSize: '150g', calories: 205, proteinG: 34, carbsG: 0, fatG: 7 },
];

export const DEFAULT_PERSONAL_RECORDS: PersonalRecord[] = [
  { exerciseName: 'Bench Press', weightKg: 70, reps: 8, dateISO: '2026-08-01', previousRecordKg: 65 },
  { exerciseName: 'Squat', weightKg: 100, reps: 6, dateISO: '2026-08-05', previousRecordKg: 95 },
  { exerciseName: 'Deadlift', weightKg: 120, reps: 5, dateISO: '2026-08-08', previousRecordKg: 110 },
  { exerciseName: 'Pull-ups', weightKg: 0, reps: 15, dateISO: '2026-08-10', previousRecordKg: 12 },
];

export const INITIAL_CHALLENGES: Challenge[] = [
  {
    id: 'c-30day-consistency',
    title: '30-DAY CONSISTENCY',
    description: 'Complete 25 workouts in 30 days to build ironclad discipline.',
    category: 'Consistency',
    targetValue: 25,
    currentValue: 14,
    unit: 'workouts',
    daysRemaining: 12,
    isJoined: true,
    isCompleted: false,
  },
  {
    id: 'c-100-pushups',
    title: '100 PUSH-UP CHALLENGE',
    description: 'Accumulate 100 total chest push-ups across sets.',
    category: 'Repetitions',
    targetValue: 100,
    currentValue: 65,
    unit: 'push-ups',
    daysRemaining: 5,
    isJoined: true,
    isCompleted: false,
  },
  {
    id: 'c-6wk-strength',
    title: '6-WEEK STRENGTH SURGE',
    description: 'Increase selected compound lifts (Squat, Bench, Deadlift) by 5%.',
    category: 'Strength',
    targetValue: 100,
    currentValue: 80,
    unit: '% goal',
    daysRemaining: 18,
    isJoined: true,
    isCompleted: false,
  },
  {
    id: 'c-10k-steps',
    title: '10K DAILY STEPS STREAK',
    description: 'Hit 10,000 steps daily for 7 consecutive days.',
    category: 'Habit',
    targetValue: 7,
    currentValue: 5,
    unit: 'days',
    daysRemaining: 2,
    isJoined: true,
    isCompleted: false,
  }
];

export const INITIAL_BODY_MEASUREMENTS: BodyMeasurementLog[] = [
  { dateISO: '2026-06-01', weightKg: 80.0, waistCm: 86, chestCm: 101, armsCm: 36, thighsCm: 58, bodyFatPercentage: 19.5, weekLabel: 'Week 1' },
  { dateISO: '2026-06-28', weightKg: 78.2, waistCm: 84, chestCm: 102, armsCm: 36.5, thighsCm: 58.5, bodyFatPercentage: 17.8, weekLabel: 'Week 4' },
  { dateISO: '2026-07-26', weightKg: 77.0, waistCm: 82, chestCm: 103, armsCm: 37, thighsCm: 59, bodyFatPercentage: 16.2, weekLabel: 'Week 8' },
  { dateISO: '2026-08-12', weightKg: 76.5, waistCm: 81, chestCm: 104, armsCm: 37.5, thighsCm: 59.5, bodyFatPercentage: 15.0, weekLabel: 'Week 12' },
];

export const SAMPLE_WORKOUT_HISTORY: CompletedWorkoutLog[] = [
  {
    id: 'log-1',
    workoutId: 'w-chest-triceps',
    workoutTitle: 'Chest + Triceps Hypertrophy',
    dateISO: new Date(Date.now() - 86400000 * 2).toISOString(),
    dateFormatted: '2 days ago',
    durationSeconds: 3120, // 52 mins
    totalVolumeKg: 4820,
    totalSetsCompleted: 12,
    totalExercisesCount: 5,
    exerciseLogs: [
      { exerciseName: 'Incline Dumbbell Press', sets: [{ weightKg: 24, reps: 10 }, { weightKg: 26, reps: 10 }] },
      { exerciseName: 'Flat Barbell Bench Press', sets: [{ weightKg: 70, reps: 8 }, { weightKg: 70, reps: 8 }] }
    ]
  },
  {
    id: 'log-2',
    workoutId: 'w-back-biceps',
    workoutTitle: 'Back + Biceps Thickness',
    dateISO: new Date(Date.now() - 86400000 * 3).toISOString(),
    dateFormatted: '3 days ago',
    durationSeconds: 3300,
    totalVolumeKg: 5100,
    totalSetsCompleted: 14,
    totalExercisesCount: 5,
    exerciseLogs: [
      { exerciseName: 'Wide Grip Lat Pulldown', sets: [{ weightKg: 60, reps: 10 }, { weightKg: 65, reps: 8 }] }
    ]
  }
];
