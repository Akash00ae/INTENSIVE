import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Header } from './components/Header';
import { Navigation, NavTab } from './components/Navigation';
import { HomeDashboard } from './components/HomeDashboard';
import { WorkoutLibraryView } from './components/WorkoutLibraryView';
import { ProgramsView } from './components/ProgramsView';
import { ProgressDashboardView } from './components/ProgressDashboardView';
import { NutritionDashboardView } from './components/NutritionDashboardView';
import { ChallengesView } from './components/ChallengesView';
import { TransformationView } from './components/TransformationView';
import { AICoachView } from './components/AICoachView';
import { ProfileView } from './components/ProfileView';
import { WorkoutPlayerModal } from './components/WorkoutPlayerModal';
import { OnboardingModal } from './components/OnboardingModal';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { storage } from './services/storage';
import { Workout, UserProfile, CompletedWorkoutLog, TrainingProgram } from './types/fitness';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [profile, setProfile] = useState<UserProfile>(storage.getProfile());
  const [isOnboarding, setIsOnboarding] = useState(storage.needsOnboarding());
  const [activeWorkout, setActiveWorkout] = useState<Workout | null>(null);
  const [workoutLogs, setWorkoutLogs] = useState<CompletedWorkoutLog[]>(storage.getWorkoutLogs());
  const [currentProgram, setCurrentProgram] = useState<TrainingProgram>(storage.getActiveProgram());
  const [workoutsList, setWorkoutsList] = useState<Workout[]>(storage.getWorkouts());

  // Handle PWA App Shortcuts (e.g. /?shortcut=workout)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shortcut = params.get('shortcut');
    if (shortcut === 'workout') {
      const today = workoutsList[0];
      if (today) setActiveWorkout(today);
    } else if (shortcut === 'nutrition') {
      setActiveTab('nutrition');
    } else if (shortcut === 'coach') {
      setActiveTab('coach');
    }
  }, [workoutsList]);

  useEffect(() => {
    const handleStorageUpdate = () => {
      setProfile(storage.getProfile());
      setWorkoutLogs(storage.getWorkoutLogs());
      setCurrentProgram(storage.getActiveProgram());
      setWorkoutsList(storage.getWorkouts());
      setIsOnboarding(storage.needsOnboarding());
    };

    window.addEventListener('mk_storage_updated', handleStorageUpdate);
    return () => window.removeEventListener('mk_storage_updated', handleStorageUpdate);
  }, []);

  const handleOnboardingComplete = (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    setIsOnboarding(false);
  };

  const handleResetData = () => {
    if (window.confirm("Are you sure you want to reset all data and restart onboarding?")) {
      storage.resetAllData();
      setProfile(storage.getProfile());
      setIsOnboarding(true);
      setActiveTab('home');
    }
  };

  const todayWorkout = workoutsList[0] || {
    id: 'w-default',
    title: 'Upper Body Hypertrophy',
    goal: 'Build Muscle',
    primaryMuscles: ['Chest', 'Arms'],
    durationMinutes: 52,
    difficulty: 'Intermediate',
    description: 'Focus on chest, back, and arm progressive overload.',
    exercises: []
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#EAEAEA] flex flex-col font-sans selection:bg-[#D4FF44] selection:text-black">
      {/* Top Application Header */}
      <Header
        onOpenAICoach={() => setActiveTab('coach')}
        onStartTodayWorkout={() => setActiveWorkout(todayWorkout)}
      />

      {/* Main Body Layout */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Navigation Sidebar (Desktop) / Fixed Bottom Bar (Mobile) */}
        <Navigation
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
        />

        {/* Content View Routing with Smooth Opacity Fade Transitions */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto pb-28 md:pb-8">
          {/* PWA Install Banner */}
          <PWAInstallBanner />

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              {activeTab === 'home' && (
                <HomeDashboard
                  userProfile={profile}
                  todayWorkout={todayWorkout}
                  currentProgram={currentProgram}
                  workoutLogs={workoutLogs}
                  onStartWorkout={(workout) => setActiveWorkout(workout)}
                  onNavigateTab={(tab) => setActiveTab(tab)}
                  onOpenAICoach={() => setActiveTab('coach')}
                />
              )}

              {activeTab === 'workouts' && (
                <WorkoutLibraryView
                  onStartWorkout={(workout) => setActiveWorkout(workout)}
                />
              )}

              {activeTab === 'programs' && (
                <ProgramsView
                  onSelectProgram={(program) => {
                    storage.saveActiveProgram(program);
                    setCurrentProgram(program);
                    setActiveTab('home');
                  }}
                />
              )}

              {activeTab === 'progress' && (
                <ProgressDashboardView />
              )}

              {activeTab === 'transformation' && (
                <TransformationView />
              )}

              {activeTab === 'nutrition' && (
                <NutritionDashboardView />
              )}

              {activeTab === 'coach' && (
                <AICoachView />
              )}

              {activeTab === 'challenges' && (
                <ChallengesView />
              )}

              {activeTab === 'profile' && (
                <ProfileView
                  userProfile={profile}
                  onUpdateProfile={(updated) => {
                    storage.saveProfile(updated);
                    setProfile(updated);
                  }}
                  onResetData={handleResetData}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Interactive Active Workout Modal */}
      {activeWorkout && (
        <WorkoutPlayerModal
          workout={activeWorkout}
          onClose={() => setActiveWorkout(null)}
          onFinishWorkout={() => {
            setActiveWorkout(null);
            setWorkoutLogs(storage.getWorkoutLogs());
          }}
        />
      )}

      {/* First-time Onboarding Modal */}
      {isOnboarding && (
        <OnboardingModal
          isOpen={isOnboarding}
          onComplete={handleOnboardingComplete}
        />
      )}
    </div>
  );
};

export default App;
