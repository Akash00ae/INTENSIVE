export type FitnessGoal = 'Lose Fat' | 'Build Muscle' | 'Increase Strength' | 'Improve Fitness' | 'Athletic Performance';
export type ExperienceLevel = 'Beginner' | 'Intermediate' | 'Advanced';
export type MuscleGroup = 'Chest' | 'Back' | 'Shoulders' | 'Arms' | 'Legs' | 'Glutes' | 'Core' | 'Full Body';
export type Equipment = 'No Equipment' | 'Dumbbells' | 'Home Gym' | 'Full Gym';

export interface UserProfile {
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Prefer not to say';
  heightCm: number;
  heightUnit?: 'cm' | 'ft/in';
  weightKg: number;
  weightUnit?: 'kg' | 'lb';
  targetWeightKg: number;
  optionalMeasurements?: {
    waistCm?: number;
    chestCm?: number;
    armsCm?: number;
    thighsCm?: number;
  };
  trainingDurationExperience?: string; // e.g. "1–2 years"
  experience: ExperienceLevel;
  goal: FitnessGoal;
  secondaryGoals?: string[];
  physiquePriorities?: string[];
  trainingDaysPerWeek: number;
  preferredDurationMin: number;
  location?: 'Full Gym' | 'Home Gym' | 'Home' | 'Outdoor' | 'Mixed';
  availableEquipmentList?: string[];
  equipment: Equipment;
  preferredTrainingTypes?: string[];
  perceivedIntensity?: 'Moderate' | 'Challenging' | 'Very Intense';
  outsideActivity?: 'Mostly sedentary' | 'Lightly active' | 'Moderately active' | 'Very active';
  dailySteps?: string;
  sleepDuration?: string;
  workLifeActivity?: 'Desk-based' | 'Mixed' | 'Physically active';
  preferredSplit?: 'Full Body' | 'Upper / Lower' | 'Push / Pull / Legs' | 'Body-Part Split' | 'Let INTENSIVE decide';
  estimatedDailyCalories?: number;
  estimatedDailyProteinG?: number;
  currentProgramId?: string;
  isOnboarded: boolean;
  streakDays: number;
  lastWorkoutDate?: string; // YYYY-MM-DD
}

export interface ExerciseSet {
  setNumber: number;
  targetReps: number;
  targetWeightKg: number;
  completedReps?: number;
  completedWeightKg?: number;
  isCompleted?: boolean;
}

export interface Exercise {
  id: string;
  name: string;
  targetMuscle: MuscleGroup;
  secondaryMuscles?: MuscleGroup[];
  equipment: Equipment;
  instructions?: string;
  defaultSets: number;
  defaultReps: number;
  defaultWeightKg: number;
  restSeconds: number;
}

export interface WorkoutExercise {
  exerciseId: string;
  exerciseName: string;
  targetMuscle: MuscleGroup;
  restSeconds: number;
  sets: ExerciseSet[];
}

export interface Workout {
  id: string;
  title: string;
  goal: FitnessGoal;
  primaryMuscles: MuscleGroup[];
  durationMinutes: number;
  difficulty: ExperienceLevel;
  exercises: WorkoutExercise[];
  description: string;
  isCustom?: boolean;
}

export interface TrainingProgram {
  id: string;
  title: string;
  tagline: string;
  goal: FitnessGoal;
  durationWeeks: number;
  daysPerWeek: number;
  durationMinutes: number;
  difficulty: ExperienceLevel;
  equipment: Equipment;
  description: string;
  weeklySchedule: {
    dayNumber: number;
    title: string;
    workoutId?: string;
    isRestDay: boolean;
  }[];
}

export interface CompletedWorkoutLog {
  id: string;
  workoutId: string;
  workoutTitle: string;
  dateISO: string; // ISO string
  dateFormatted: string;
  durationSeconds: number;
  totalVolumeKg: number;
  totalSetsCompleted: number;
  totalExercisesCount: number;
  exerciseLogs: {
    exerciseName: string;
    sets: { weightKg: number; reps: number }[];
  }[];
}

export interface PersonalRecord {
  exerciseName: string;
  weightKg: number;
  reps: number;
  dateISO: string;
  previousRecordKg?: number;
}

export interface WeightLog {
  dateISO: string;
  weightKg: number;
}

export interface BodyMeasurementLog {
  dateISO: string;
  waistCm?: number;
  chestCm?: number;
  armsCm?: number;
  thighsCm?: number;
  bodyFatPercentage?: number;
  photoUrl?: string; // Base64 or sample URL
  weekLabel?: string; // e.g., 'Week 1', 'Week 4'
}

export interface FoodItem {
  id: string;
  name: string;
  category: 'Indian' | 'Global' | 'Snack' | 'Protein' | 'Beverage';
  servingSize: string;
  calories: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
}

export interface MealLog {
  id: string;
  dateISO: string; // YYYY-MM-DD
  mealType: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks';
  foodName: string;
  servings: number;
  calories: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
}

export interface WaterLog {
  dateISO: string; // YYYY-MM-DD
  liters: number;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  category: 'Consistency' | 'Strength' | 'Repetitions' | 'Habit';
  targetValue: number;
  currentValue: number;
  unit: string;
  daysRemaining: number;
  isJoined: boolean;
  isCompleted: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}
